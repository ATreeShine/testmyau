package myau.module.modules;

import myau.Myau;
import myau.event.EventTarget;
import myau.event.types.EventType;
import myau.event.types.Priority;
import myau.events.*;
import myau.management.RotationState;
import myau.mixin.IAccessorMinecraft;
import myau.module.Module;
import myau.property.properties.BooleanProperty;
import myau.property.properties.FloatProperty;
import myau.property.properties.ModeProperty;
import myau.property.properties.PercentProperty;
import myau.util.*;
import net.minecraft.block.Block;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.FontRenderer;
import net.minecraft.client.gui.ScaledResolution;
import net.minecraft.client.renderer.GlStateManager;
import net.minecraft.item.ItemBlock;
import net.minecraft.item.ItemStack;
import net.minecraft.network.play.client.C0APacketAnimation;
import net.minecraft.potion.Potion;
import net.minecraft.util.*;
import net.minecraft.util.MovingObjectPosition.MovingObjectType;
import net.minecraft.world.WorldSettings.GameType;
import org.lwjgl.opengl.GL11;

import java.util.ArrayList;
import java.util.Comparator;

public class NewScaff extends Module {
    private static final Minecraft mc = Minecraft.getMinecraft();
    private static final int ROTATIONS_NONE = 0;
    private static final int ROTATIONS_BACKWARDS = 2;
    private static final int ROTATIONS_SIDEWAYS = 3;
    private static final int MOVE_FIX_SILENT = 1;
    private static final int SPRINT_NONE = 0;
    private static final int FAST_NONE = 0;
    private static final int FAST_WATCHDOG = 1;
    private static final int FAST_WATCHDOG2 = 2;
    private static final int FAST_WATCHDOG3 = 3;
    private static final int TOWER_NONE = 0;
    private static final int TOWER_VANILLA = 1;
    private static final int TOWER_EXTRA = 2;
    private static final int TOWER_TELLY = 3;
    private static final int TOWER_WATCHDOG = 4;
    private static final int TOWER_WATCHDOG_LOW = 5;
    private static final int KEEP_Y_NONE = 0;
    private static final int KEEP_Y_VANILLA = 1;
    private static final int KEEP_Y_EXTRA = 2;
    private static final int KEEP_Y_TELLY = 3;
    // Midpoint samples used when searching for a visible point on a block face.
    private static final double[] FACE_SAMPLE_OFFSETS = {
            0.03125D, 0.09375D, 0.15625D, 0.21875D,
            0.28125D, 0.34375D, 0.40625D, 0.46875D,
            0.53125D, 0.59375D, 0.65625D, 0.71875D,
            0.78125D, 0.84375D, 0.90625D, 0.96875D
    };
    // Placement and hotbar ownership.
    private int placementDelayTicks;
    private int previousHotbarSlot;
    private int remainingStackBlocks;
    private float placementYaw;
    private float placementPitch;
    private boolean hasPlacementRotation;
    // Tower phases and height-lock recovery.
    private int towerPhase;
    private int towerCycleCount;
    private int keepYState;
    private int keepYLevel;
    private boolean keepYRecoveryPlacement;
    private boolean tellyRotationActive;
    private EnumFacing pendingPlacementFace;
    // Fast mode and Watchdog state.
    private float headYaw;
    private boolean onGroundState;
    private boolean watchdog2Flag;
    private int watchdog3PlaceDelay;
    private int timerTickCounter;
    private boolean timerActive;
    public final ModeProperty rotations = new ModeProperty(
            "rotations",
            ROTATIONS_BACKWARDS,
            new String[]{"NONE", "DEFAULT", "BACKWARDS", "SIDEWAYS"}
    );
    public final ModeProperty moveFix = new ModeProperty(
            "move-fix", MOVE_FIX_SILENT, new String[]{"NONE", "SILENT"}
    );
    public final ModeProperty sprint = new ModeProperty(
            "sprint", SPRINT_NONE, new String[]{"NONE", "VANILLA"}
    );
    public final ModeProperty fastMode = new ModeProperty(
            "fast-mode",
            FAST_NONE,
            new String[]{"NONE", "WATCHDOG", "WATCHDOG2", "WATCHDOG3"}
    );
    public final PercentProperty groundMotion = new PercentProperty("ground-motion", 100);
    public final PercentProperty airMotion = new PercentProperty("air-motion", 100);
    public final PercentProperty speedMotion = new PercentProperty("speed-motion", 100);
    public final ModeProperty tower = new ModeProperty(
            "tower",
            TOWER_NONE,
            new String[]{"NONE", "VANILLA", "EXTRA", "TELLY", "WATCHDOG", "WATCHDOG LOW"}
    );
    public final FloatProperty timerTicks = new FloatProperty(
            "timer-ticks",
            10.0F,
            2.0F,
            15.0F,
            () -> this.tower.getValue() == TOWER_WATCHDOG_LOW
    );
    public final ModeProperty keepY = new ModeProperty(
            "keep-y",
            KEEP_Y_NONE,
            new String[]{"NONE", "VANILLA", "EXTRA", "TELLY"}
    );
    public final BooleanProperty keepYOnPress = new BooleanProperty("keep-y-on-press", false, this::isKeepYOnPressVisible);
    public final BooleanProperty multiPlace = new BooleanProperty("multi-place", true);
    public final BooleanProperty safeWalk = new BooleanProperty("safe-walk", true);
    public final BooleanProperty swing = new BooleanProperty("swing", true);
    public final BooleanProperty itemSpoof = new BooleanProperty("item-spoof", false);
    public final BooleanProperty blockCounter = new BooleanProperty("block-counter", true);

    public NewScaff() {
        super("NewScaff", false);
        this.placementDelayTicks = 0;
        this.previousHotbarSlot = -1;
        this.remainingStackBlocks = -1;
        this.placementYaw = -180.0F;
        this.placementPitch = 0.0F;
        this.hasPlacementRotation = false;
        this.towerPhase = 0;
        this.towerCycleCount = 0;
        this.keepYState = 0;
        this.keepYLevel = 256;
        this.keepYRecoveryPlacement = false;
        this.tellyRotationActive = false;
        this.pendingPlacementFace = null;
        this.headYaw = 0.0F;
        this.onGroundState = false;
        this.watchdog2Flag = false;
        this.watchdog3PlaceDelay = 0;
        this.timerTickCounter = 0;
        this.timerActive = false;
    }

    public int getSlot() {
        return this.previousHotbarSlot;
    }

    public int getPreviousHotbarSlot() {
        return this.previousHotbarSlot;
    }

    private boolean shouldDisableSprint() {
        if (this.isTellyTakeoff()) {
            return false;
        }

        if (this.fastMode.getValue() != FAST_NONE) {
            return false;
        }

        boolean standardKeepY = this.keepY.getValue() == KEEP_Y_VANILLA || this.keepY.getValue() == KEEP_Y_EXTRA;
        if (standardKeepY && this.keepYState > 0) {
            return false;
        }

        return this.sprint.getValue() == SPRINT_NONE;
    }

    private boolean canPlaceWithActiveModules() {
        BedNuker bedNuker = (BedNuker) Myau.moduleManager.modules.get(BedNuker.class);
        if (bedNuker.isEnabled() && bedNuker.isReady()) {
            return false;
        }

        LongJump longJump = (LongJump) Myau.moduleManager.modules.get(LongJump.class);
        return !longJump.isEnabled() || !longJump.isAutoMode() || longJump.isJumping();
    }

    private EnumFacing findConnectingFace(BlockPos supportBlock, BlockPos desiredPlacementBlock) {
        EnumFacing bestFace = null;
        double bestDistanceSquared = 0.0;

        for (EnumFacing candidateFace : EnumFacing.VALUES) {
            if (candidateFace == EnumFacing.DOWN) {
                continue;
            }

            BlockPos neighborBlock = supportBlock.offset(candidateFace);
            if (neighborBlock.getY() > desiredPlacementBlock.getY()) {
                continue;
            }

            double distanceSquared = neighborBlock.distanceSqToCenter(
                    desiredPlacementBlock.getX() + 0.5,
                    desiredPlacementBlock.getY() + 0.5,
                    desiredPlacementBlock.getZ() + 0.5
            );

            if (bestFace == null
                    || distanceSquared < bestDistanceSquared
                    || distanceSquared == bestDistanceSquared && candidateFace == EnumFacing.UP) {
                bestDistanceSquared = distanceSquared;
                bestFace = candidateFace;
            }
        }

        return bestFace;
    }

    private BlockPlacementTarget findPlacementTarget() {
        int playerBlockY = MathHelper.floor_double(mc.thePlayer.posY);
        int placementY = this.keepYState != 0 && !this.keepYRecoveryPlacement
                ? Math.min(playerBlockY, this.keepYLevel)
                : playerBlockY;
        BlockPos desiredPlacementBlock = new BlockPos(
                MathHelper.floor_double(mc.thePlayer.posX),
                placementY - 1,
                MathHelper.floor_double(mc.thePlayer.posZ)
        );

        if (!BlockUtil.isReplaceable(desiredPlacementBlock)) {
            return null;
        }

        ArrayList<BlockPos> supportCandidates = new ArrayList<>();
        double blockReach = mc.playerController.getBlockReachDistance();

        for (int offsetX = -4; offsetX <= 4; offsetX++) {
            for (int offsetY = -4; offsetY <= 0; offsetY++) {
                for (int offsetZ = -4; offsetZ <= 4; offsetZ++) {
                    BlockPos candidateBlock = desiredPlacementBlock.add(offsetX, offsetY, offsetZ);
                    if (BlockUtil.isReplaceable(candidateBlock) || BlockUtil.isInteractable(candidateBlock)) {
                        continue;
                    }

                    double distanceToCandidate = mc.thePlayer.getDistance(
                            candidateBlock.getX() + 0.5,
                            candidateBlock.getY() + 0.5,
                            candidateBlock.getZ() + 0.5
                    );
                    if (distanceToCandidate > blockReach) {
                        continue;
                    }

                    if (this.keepYState != 0
                            && !this.keepYRecoveryPlacement
                            && candidateBlock.getY() >= this.keepYLevel) {
                        continue;
                    }

                    for (EnumFacing face : EnumFacing.VALUES) {
                        if (face != EnumFacing.DOWN && BlockUtil.isReplaceable(candidateBlock.offset(face))) {
                            supportCandidates.add(candidateBlock);
                        }
                    }
                }
            }
        }

        if (supportCandidates.isEmpty()) {
            return null;
        }

        supportCandidates.sort(Comparator.comparingDouble(
                supportCandidate -> targetDistanceSquared(desiredPlacementBlock, supportCandidate)
        ));
        BlockPos selectedSupportBlock = supportCandidates.get(0);
        EnumFacing connectingFace = this.findConnectingFace(selectedSupportBlock, desiredPlacementBlock);
        return connectingFace == null ? null : new BlockPlacementTarget(selectedSupportBlock, connectingFace);
    }

    private void placeBlock(BlockPos position, EnumFacing facing, Vec3 hitVector) {
        if (!ItemUtil.isHoldingBlock() || this.remainingStackBlocks <= 0) {
            return;
        }

        boolean placed = mc.playerController.onPlayerRightClick(
                mc.thePlayer,
                mc.theWorld,
                mc.thePlayer.inventory.getCurrentItem(),
                position,
                facing,
                hitVector
        );
        if (!placed) {
            return;
        }

        this.watchdog3PlaceDelay = 10;

        if (mc.playerController.getCurrentGameType() != GameType.CREATIVE) {
            this.remainingStackBlocks--;
        }

        if (this.swing.getValue()) {
            mc.thePlayer.swingItem();
        } else {
            PacketUtil.sendPacket(new C0APacketAnimation());
        }
    }

    private EnumFacing facingFromYaw(float yaw) {
        if (yaw < -135.0F || yaw > 135.0F) {
            return EnumFacing.NORTH;
        }
        if (yaw < -45.0F) {
            return EnumFacing.EAST;
        }
        if (yaw < 45.0F) {
            return EnumFacing.SOUTH;
        }
        return EnumFacing.WEST;
    }

    private double distanceToBlockEdge(EnumFacing facing) {
        switch (facing) {
            case NORTH:
                return mc.thePlayer.posZ - Math.floor(mc.thePlayer.posZ);
            case EAST:
                return Math.ceil(mc.thePlayer.posX) - mc.thePlayer.posX;
            case SOUTH:
                return Math.ceil(mc.thePlayer.posZ) - mc.thePlayer.posZ;
            case WEST:
            default:
                return mc.thePlayer.posX - Math.floor(mc.thePlayer.posX);
        }
    }

    private float getMotionMultiplier() {
        int percent;
        if (!mc.thePlayer.onGround) {
            percent = this.airMotion.getValue();
        } else if (MoveUtil.getSpeedLevel() > 0) {
            percent = this.speedMotion.getValue();
        } else {
            percent = this.groundMotion.getValue();
        }
        return percent / 100.0F;
    }

    private double randomEdgeApproachDistance() {
        return 0.2155 - RandomUtil.nextDouble(0.0001, 0.0009);
    }

    private float getMovementYaw() {
        return MoveUtil.adjustYaw(mc.thePlayer.rotationYaw, (float) MoveUtil.getForwardValue(), (float) MoveUtil.getLeftValue());
    }

    private boolean isDiagonalYaw(float angle) {
        float remainder = Math.abs(angle % 90.0F);
        return remainder > 20.0F && remainder < 70.0F;
    }

    private boolean isTellyTakeoff() {
        if (!mc.thePlayer.onGround || !MoveUtil.isForwardPressed()) {
            return false;
        }
        if (PlayerUtil.isAirAbove()) {
            return false;
        }
        if (this.keepY.getValue() == KEEP_Y_TELLY && this.keepYState > 0) {
            return true;
        }
        return this.tower.getValue() == TOWER_TELLY && mc.gameSettings.keyBindJump.isKeyDown();
    }

    private void selectPlacementHotbarSlot() {
        ItemStack heldStack = mc.thePlayer.getHeldItem();
        int heldStackSize = ItemUtil.isBlock(heldStack) ? heldStack.stackSize : 0;
        this.remainingStackBlocks = Math.min(this.remainingStackBlocks, heldStackSize);
        if (this.remainingStackBlocks > 0) {
            return;
        }

        int searchStartSlot = mc.thePlayer.inventory.currentItem;
        if (this.remainingStackBlocks == 0) {
            searchStartSlot--;
        }

        for (int slotCursor = searchStartSlot; slotCursor > searchStartSlot - 9; slotCursor--) {
            int hotbarSlot = (slotCursor % 9 + 9) % 9;
            ItemStack candidateStack = mc.thePlayer.inventory.getStackInSlot(hotbarSlot);
            if (ItemUtil.isBlock(candidateStack)) {
                mc.thePlayer.inventory.currentItem = hotbarSlot;
                this.remainingStackBlocks = candidateStack.stackSize;
                return;
            }
        }
    }

    private Vec3 findBestPlacementHit(BlockPlacementTarget placementTarget, float previousYaw, float previousPitch) {
        if (placementTarget == null) {
            return null;
        }

        double[] hitOffsetsX = FACE_SAMPLE_OFFSETS;
        double[] hitOffsetsY = FACE_SAMPLE_OFFSETS;
        double[] hitOffsetsZ = FACE_SAMPLE_OFFSETS;
        switch (placementTarget.face()) {
            case NORTH:
                hitOffsetsZ = new double[]{0.0};
                break;
            case EAST:
                hitOffsetsX = new double[]{1.0};
                break;
            case SOUTH:
                hitOffsetsZ = new double[]{1.0};
                break;
            case WEST:
                hitOffsetsX = new double[]{0.0};
                break;
            case DOWN:
                hitOffsetsY = new double[]{0.0};
                break;
            case UP:
                hitOffsetsY = new double[]{1.0};
                break;
            default:
                break;
        }

        float bestYaw = -180.0F;
        float bestPitch = 0.0F;
        float bestRotationCost = 0.0F;
        Vec3 bestHit = null;

        for (double hitOffsetX : hitOffsetsX) {
            for (double hitOffsetY : hitOffsetsY) {
                for (double hitOffsetZ : hitOffsetsZ) {
                    double deltaX = placementTarget.position().getX() + hitOffsetX - mc.thePlayer.posX;
                    double deltaY = placementTarget.position().getY() + hitOffsetY
                            - mc.thePlayer.posY - mc.thePlayer.getEyeHeight();
                    double deltaZ = placementTarget.position().getZ() + hitOffsetZ - mc.thePlayer.posZ;
                    float[] candidateRotations = rotationsFromDelta(deltaX, deltaY, deltaZ);
                    candidateRotations[0] = snapToMouseSensitivity(candidateRotations[0], previousYaw);
                    candidateRotations[1] = snapToMouseSensitivity(candidateRotations[1], previousPitch);
                    candidateRotations[1] = MathHelper.clamp_float(candidateRotations[1], -90.0F, 90.0F);

                    MovingObjectPosition candidateHit = RotationUtil.rayTrace(
                            candidateRotations[0],
                            candidateRotations[1],
                            mc.playerController.getBlockReachDistance(),
                            1.0F
                    );
                    if (candidateHit == null
                            || candidateHit.typeOfHit != MovingObjectType.BLOCK
                            || !candidateHit.getBlockPos().equals(placementTarget.position())
                            || candidateHit.sideHit != placementTarget.face()) {
                        continue;
                    }

                    float rotationCost = Math.abs(MathHelper.wrapAngleTo180_float(candidateRotations[0] - this.placementYaw))
                            + Math.abs(candidateRotations[1] - this.placementPitch);
                    if (bestYaw == -180.0F && bestPitch == 0.0F || rotationCost < bestRotationCost) {
                        bestYaw = candidateRotations[0];
                        bestPitch = candidateRotations[1];
                        bestRotationCost = rotationCost;
                        bestHit = candidateHit.hitVec;
                    }
                }
            }
        }

        if (bestYaw != -180.0F || bestPitch != 0.0F) {
            this.placementYaw = bestYaw;
            this.placementPitch = bestPitch;
            this.hasPlacementRotation = true;
        }
        return bestHit;
    }

    private void applyPlacementRotation(
            UpdateEvent event,
            float previousYaw,
            float previousPitch,
            float backwardYaw,
            float sidewaysYaw
    ) {
        if (this.fastMode.getValue() == FAST_WATCHDOG3) {
            event.setRotation(this.placementYaw, this.placementPitch, 3);
            if (this.moveFix.getValue() == MOVE_FIX_SILENT) {
                event.setPervRotation(this.placementYaw, 3);
            }
            return;
        }

        if (this.hasPlacementRotation && MoveUtil.isForwardPressed()) {
            float backwardYawDifference = Math.abs(MathHelper.wrapAngleTo180_float(backwardYaw - this.placementYaw));
            if (backwardYawDifference < 90.0F) {
                switch (this.rotations.getValue()) {
                    case ROTATIONS_BACKWARDS:
                        this.placementYaw = snapToMouseSensitivity(backwardYaw, previousYaw);
                        break;
                    case ROTATIONS_SIDEWAYS:
                        this.placementYaw = snapToMouseSensitivity(sidewaysYaw, previousPitch);
                        break;
                    default:
                        break;
                }
            }
        }

        if (this.rotations.getValue() == ROTATIONS_NONE) {
            return;
        }

        float requestedYaw = this.placementYaw;
        float requestedPitch = this.placementPitch;
        if (this.isTellyTakeoff()) {
            float playerYawDifference = MathHelper.wrapAngleTo180_float(
                    mc.thePlayer.rotationYaw - event.getYaw()
            );
            requestedYaw = snapToMouseSensitivity(
                    previousYaw + playerYawDifference * RandomUtil.nextFloat(0.98F, 0.99F),
                    previousYaw
            );
            requestedPitch = snapToMouseSensitivity(
                    RandomUtil.nextFloat(30.0F, 80.0F),
                    previousPitch
            );
            this.placementDelayTicks = 3;
            this.tellyRotationActive = true;
        } else {
            float placementYawDifference = MathHelper.wrapAngleTo180_float(this.placementYaw - event.getYaw());
            float maxYawChange = RandomUtil.nextFloat(80.0F, 90.0F);
            if (this.fastMode.getValue() == FAST_WATCHDOG && this.onGroundState) {
                maxYawChange = (float) (89.0 - Math.random());
            } else if (this.fastMode.getValue() == FAST_WATCHDOG2) {
                if (this.watchdog2Flag) {
                    maxYawChange = (float) (129.0 - Math.random());
                    this.watchdog2Flag = false;
                } else {
                    maxYawChange = 34.0F;
                }
                if (this.onGroundState) {
                    this.watchdog2Flag = true;
                }
            } else if (this.tellyRotationActive && mc.thePlayer.motionY > 0.0 && this.placementDelayTicks <= 1) {
                maxYawChange = RandomUtil.nextFloat(30.0F, 35.0F);
            }

            if (Math.abs(placementYawDifference) > maxYawChange) {
                float clampedYawChange = RotationUtil.clampAngle(placementYawDifference, maxYawChange);
                requestedYaw = snapToMouseSensitivity(previousYaw + clampedYawChange, previousYaw);
                this.placementDelayTicks = Math.max(this.placementDelayTicks, 1);
            }
        }

        event.setRotation(requestedYaw, requestedPitch, 3);
        if (this.moveFix.getValue() == MOVE_FIX_SILENT) {
            event.setPervRotation(requestedYaw, 3);
        }
    }

    private void placeCurrentAndAdditionalBlocks(BlockPlacementTarget placementTarget, Vec3 placementHit) {
        boolean isWatchdogTower = this.tower.getValue() == TOWER_WATCHDOG || this.tower.getValue() == TOWER_WATCHDOG_LOW;
        if (isWatchdogTower && mc.gameSettings.keyBindJump.isKeyDown() && mc.thePlayer.onGround) {
            return;
        }

        if (placementTarget == null || placementHit == null || this.placementDelayTicks > 0) {
            return;
        }

        this.placeBlock(placementTarget.position(), placementTarget.face(), placementHit);
        if (!this.multiPlace.getValue()) {
            return;
        }

        for (int extraPlacementIndex = 0; extraPlacementIndex < 3; extraPlacementIndex++) {
            placementTarget = this.findPlacementTarget();
            if (placementTarget == null) {
                break;
            }

            MovingObjectPosition extraPlacementHit = RotationUtil.rayTrace(
                    this.placementYaw,
                    this.placementPitch,
                    mc.playerController.getBlockReachDistance(),
                    1.0F
            );
            if (extraPlacementHit != null
                    && extraPlacementHit.typeOfHit == MovingObjectType.BLOCK
                    && extraPlacementHit.getBlockPos().equals(placementTarget.position())
                    && extraPlacementHit.sideHit == placementTarget.face()) {
                this.placeBlock(placementTarget.position(), placementTarget.face(), extraPlacementHit.hitVec);
                continue;
            }

            Vec3 fallbackHit = BlockUtil.getClickVec(placementTarget.position(), placementTarget.face());
            double fallbackDeltaX = fallbackHit.xCoord - mc.thePlayer.posX;
            double fallbackDeltaY = fallbackHit.yCoord - mc.thePlayer.posY - mc.thePlayer.getEyeHeight();
            double fallbackDeltaZ = fallbackHit.zCoord - mc.thePlayer.posZ;
            float[] fallbackRotations = rotationsFromDelta(fallbackDeltaX, fallbackDeltaY, fallbackDeltaZ);
            if (Math.abs(MathHelper.wrapAngleTo180_float(fallbackRotations[0] - this.placementYaw)) >= 120.0F
                    || Math.abs(fallbackRotations[1] - this.placementPitch) >= 60.0F) {
                break;
            }

            extraPlacementHit = RotationUtil.rayTrace(
                    fallbackRotations[0],
                    fallbackRotations[1],
                    mc.playerController.getBlockReachDistance(),
                    1.0F
            );
            if (extraPlacementHit == null
                    || extraPlacementHit.typeOfHit != MovingObjectType.BLOCK
                    || !extraPlacementHit.getBlockPos().equals(placementTarget.position())
                    || extraPlacementHit.sideHit != placementTarget.face()) {
                break;
            }

            this.placeBlock(placementTarget.position(), placementTarget.face(), extraPlacementHit.hitVec);
        }
    }

    private boolean handlePendingTowerPlacement() {
        if (this.pendingPlacementFace == null) {
            return false;
        }

        if (this.placementDelayTicks <= 0) {
            BlockPos beneathPlayer = new BlockPos(
                    MathHelper.floor_double(mc.thePlayer.posX),
                    MathHelper.floor_double(mc.thePlayer.posY) - 1,
                    MathHelper.floor_double(mc.thePlayer.posZ)
            );
            Vec3 placementHit = BlockUtil.getHitVec(
                    beneathPlayer,
                    this.pendingPlacementFace,
                    this.placementYaw,
                    this.placementPitch
            );
            this.placeBlock(beneathPlayer, this.pendingPlacementFace, placementHit);
        }

        this.pendingPlacementFace = null;
        return true;
    }

    private void handleExtraKeepYRecovery() {
        if (this.keepY.getValue() != KEEP_Y_EXTRA || this.keepYState <= 0 || mc.thePlayer.onGround) {
            return;
        }

        int predictedBlockY = MathHelper.floor_double(mc.thePlayer.posY + mc.thePlayer.motionY);
        if (predictedBlockY > this.keepYLevel || mc.thePlayer.posY <= this.keepYLevel + 1) {
            return;
        }

        this.keepYRecoveryPlacement = true;
        BlockPlacementTarget placementTarget = this.findPlacementTarget();
        if (placementTarget == null || this.placementDelayTicks > 0) {
            return;
        }

        Vec3 placementHit = BlockUtil.getHitVec(
                placementTarget.position(),
                placementTarget.face(),
                this.placementYaw,
                this.placementPitch
        );
        this.placeBlock(placementTarget.position(), placementTarget.face(), placementHit);
    }

    // Updates placement targets, rotations, Keep-Y and deferred Tower placements.
    @EventTarget(Priority.HIGH)
    public void onUpdate(UpdateEvent event) {
        if (!this.isEnabled() || event.getType() != EventType.PRE) {
            return;
        }

        if (this.placementDelayTicks > 0) {
            this.placementDelayTicks--;
        }
        if (this.watchdog3PlaceDelay > 0) {
            this.watchdog3PlaceDelay--;
        }

        if (this.tower.getValue() != TOWER_WATCHDOG_LOW && this.timerActive) {
            ((IAccessorMinecraft) mc).getTimer().timerSpeed = 1.0F;
            this.timerActive = false;
            this.timerTickCounter = 0;
        }

        if (mc.thePlayer.onGround) {
            if (this.keepYState > 0) {
                this.keepYState--;
            }
            if (this.keepYState < 0) {
                this.keepYState++;
            }
            if (this.keepYState == 0
                    && this.keepY.getValue() != KEEP_Y_NONE
                    && (!this.keepYOnPress.getValue() || PlayerUtil.isUsingItem())
                    && !mc.gameSettings.keyBindJump.isKeyDown()
                    && !mc.thePlayer.isPotionActive(Potion.jump)) {
                this.keepYState = 1;
            }

            if (!this.keepYRecoveryPlacement) {
                this.keepYLevel = MathHelper.floor_double(mc.thePlayer.posY);
            }
            this.keepYRecoveryPlacement = false;
            this.tellyRotationActive = false;
        }

        if (!this.canPlaceWithActiveModules()) {
            return;
        }

        this.selectPlacementHotbarSlot();

        float previousYaw = event.getYaw();
        float previousPitch = event.getPitch();
        float movementYaw = this.getMovementYaw();
        float backwardYaw = movementYaw - 180.0F;
        float sidewaysYaw;
        if (this.isDiagonalYaw(movementYaw)) {
            sidewaysYaw = backwardYaw;
        } else {
            float sidewaysDirectionFactor = (movementYaw + 180.0F) % 90.0F < 45.0F ? 1.0F : -1.0F;
            sidewaysYaw = movementYaw - 135.0F * sidewaysDirectionFactor;
        }

        if (this.fastMode.getValue() == FAST_WATCHDOG3) {
            float playerYaw = mc.thePlayer.rotationYaw;
            float targetYaw = playerYaw + 45.0F;
            float yawDiff = Math.abs(MathHelper.wrapAngleTo180_float(targetYaw - this.placementYaw));

            if (this.watchdog3PlaceDelay == 10) {
                this.headYaw = this.placementYaw;
            }

            int expectedDelay = yawDiff > 60.0F ? 8 : 9;
            if (this.watchdog3PlaceDelay == expectedDelay) {
                if (!mc.gameSettings.keyBindJump.isKeyDown()) {
                    if (this.onGroundState && mc.thePlayer.onGround) {
                        this.placementYaw = snapToMouseSensitivity(playerYaw + 45.0F, previousYaw);
                        this.hasPlacementRotation = true;
                    }
                }
            }
        }

        boolean isWatchdogTower = this.tower.getValue() == TOWER_WATCHDOG || this.tower.getValue() == TOWER_WATCHDOG_LOW;
        if (isWatchdogTower && mc.thePlayer.onGround && mc.gameSettings.keyBindJump.isKeyDown()) {
            this.placementYaw = mc.thePlayer.rotationYaw;
        }

        if (!this.hasPlacementRotation) {
            if (this.placementYaw == -180.0F && this.placementPitch == 0.0F) {
                this.placementPitch = snapToMouseSensitivity(
                        RandomUtil.nextFloat(65.0F, 85.0F),
                        previousPitch
                );
            }

            if (this.fastMode.getValue() == FAST_WATCHDOG3) {
                this.placementYaw = snapToMouseSensitivity(mc.thePlayer.rotationYaw + 45.0F, previousYaw);
            } else {
                switch (this.rotations.getValue()) {
                    case ROTATIONS_BACKWARDS:
                        this.placementYaw = snapToMouseSensitivity(backwardYaw, previousYaw);
                        break;
                    case ROTATIONS_SIDEWAYS:
                    default:
                        this.placementYaw = snapToMouseSensitivity(sidewaysYaw, previousYaw);
                        break;
                }
            }
        }

        BlockPlacementTarget placementTarget = this.findPlacementTarget();
        Vec3 placementHit = this.findBestPlacementHit(placementTarget, previousYaw, previousPitch);
        this.applyPlacementRotation(event, previousYaw, previousPitch, backwardYaw, sidewaysYaw);
        this.placeCurrentAndAdditionalBlocks(placementTarget, placementHit);

        if (this.tower.getValue() == TOWER_WATCHDOG_LOW) {
            if (!mc.thePlayer.onGround) {
                if (mc.thePlayer.motionY < -0.1) {
                    if (mc.gameSettings.keyBindJump.isKeyDown()) {
                        if ((double) this.timerTickCounter < this.timerTicks.getValue()) {
                            ((IAccessorMinecraft) mc).getTimer().timerSpeed = 2.0F;
                            this.timerTickCounter++;
                            this.timerActive = true;
                        } else if (this.timerActive) {
                            ((IAccessorMinecraft) mc).getTimer().timerSpeed = 1.0F;
                            this.timerActive = false;
                        }
                    } else if (this.timerActive) {
                        ((IAccessorMinecraft) mc).getTimer().timerSpeed = 1.0F;
                        this.timerActive = false;
                    }
                } else if (this.timerActive) {
                    ((IAccessorMinecraft) mc).getTimer().timerSpeed = 1.0F;
                    this.timerActive = false;
                }
            } else if (this.timerActive) {
                ((IAccessorMinecraft) mc).getTimer().timerSpeed = 1.0F;
                this.timerActive = false;
            }
        }

        if (this.fastMode.getValue() != FAST_WATCHDOG3) {
            this.onGroundState = mc.thePlayer.onGround;
        }

        if (this.handlePendingTowerPlacement()) {
            return;
        }
        this.handleExtraKeepYRecovery();
    }

    // Checks Tower eligibility before advancing the selected Tower phase.
    @EventTarget
    public void onStrafe(StrafeEvent event) {
        if (!this.isEnabled()) {
            return;
        }

        if (this.tower.getValue() == TOWER_WATCHDOG_LOW) {
            if (!mc.gameSettings.keyBindJump.isKeyDown()) {
                if (this.timerTickCounter > 0) {
                    this.timerTickCounter--;
                    ((IAccessorMinecraft) mc).getTimer().timerSpeed = 0.5F;
                    this.timerActive = true;
                } else if (this.timerActive) {
                    ((IAccessorMinecraft) mc).getTimer().timerSpeed = 1.0F;
                    this.timerActive = false;
                }
            }
        }

        if (mc.thePlayer.isCollidedHorizontally
                || mc.thePlayer.hurtTime > 5
                || mc.thePlayer.isPotionActive(Potion.jump)
                || !mc.gameSettings.keyBindJump.isKeyDown()
                || !ItemUtil.isHoldingBlock()) {
            this.towerPhase = 0;
            this.towerCycleCount = 0;
            return;
        }

        int heightHundredths = (int) (mc.thePlayer.posY % 1.0 * 100.0);
        switch (this.tower.getValue()) {
            case TOWER_VANILLA:
                this.applyVanillaTowerMotion(heightHundredths, event);
                return;
            case TOWER_EXTRA:
                this.applyExtraTowerMotion(heightHundredths, event);
                return;
            default:
                this.towerPhase = 0;
                this.towerCycleCount = 0;
        }
    }

    // Corrects movement for spoofed yaw and applies Keep-Y jump input.
    @EventTarget
    public void onMoveInput(MoveInputEvent event) {
        if (!this.isEnabled()) {
            return;
        }

        if (this.moveFix.getValue() == MOVE_FIX_SILENT
                && RotationState.isActived()
                && RotationState.getPriority() == 3.0F
                && MoveUtil.isForwardPressed()) {
            MoveUtil.fixStrafe(RotationState.getSmoothedYaw());
        }

        if (this.fastMode.getValue() == FAST_WATCHDOG3) {
            if (!this.onGroundState && this.watchdog3PlaceDelay != 10) {
                mc.thePlayer.movementInput.jump = true;
                this.onGroundState = true;
            }
        } else if (this.fastMode.getValue() == FAST_WATCHDOG || this.fastMode.getValue() == FAST_WATCHDOG2) {
            if (mc.thePlayer.movementInput.moveStrafe != 0.0F || mc.thePlayer.movementInput.moveForward != 0.0F) {
                mc.thePlayer.movementInput.jump = true;
            }
        }

        if (!mc.thePlayer.onGround || this.keepYState <= 0 || !MoveUtil.isForwardPressed()) {
            return;
        }

        mc.thePlayer.movementInput.jump = true;
    }

    // Applies configured input scaling and the shared sprint policy.
    @EventTarget
    public void onLivingUpdate(LivingUpdateEvent event) {
        if (!this.isEnabled()) {
            return;
        }

        if (this.fastMode.getValue() == FAST_WATCHDOG3) {
            mc.thePlayer.rotationYawHead = this.headYaw;
            mc.thePlayer.renderYawOffset = this.headYaw + (mc.thePlayer.renderYawOffset - this.headYaw) * 0.5F;
        }

        float motionMultiplier = this.getMotionMultiplier();
        if (motionMultiplier != 1.0F) {
            if (mc.thePlayer.movementInput.moveForward != 0.0F
                    && mc.thePlayer.movementInput.moveStrafe != 0.0F) {
                float diagonalScale = 1.0F / (float) Math.sqrt(2.0);
                mc.thePlayer.movementInput.moveForward *= diagonalScale;
                mc.thePlayer.movementInput.moveStrafe *= diagonalScale;
            }

            mc.thePlayer.movementInput.moveForward *= motionMultiplier;
            mc.thePlayer.movementInput.moveStrafe *= motionMultiplier;
        }

        if (this.shouldDisableSprint()) {
            mc.thePlayer.setSprinting(false);
        }
    }

    // Requests SafeWalk when the current motion would leave support.
    @EventTarget
    public void onSafeWalk(SafeWalkEvent event) {
        if (!this.isEnabled()
                || !this.safeWalk.getValue()
                || !mc.thePlayer.onGround
                || mc.thePlayer.motionY > 0.0) {
            return;
        }

        if (PlayerUtil.canMove(
                mc.thePlayer.motionX,
                mc.thePlayer.motionZ,
                -1.0
        )) {
            event.setSafeWalk(true);
        }
    }

    // Counts eligible hotbar blocks before drawing the counter.
    @EventTarget
    public void onRender(Render2DEvent event) {
        if (!this.isEnabled() || !this.blockCounter.getValue()) {
            return;
        }

        int blockCount = 0;
        for (int hotbarSlot = 0; hotbarSlot < 9; hotbarSlot++) {
            ItemStack stack = mc.thePlayer.inventory.getStackInSlot(hotbarSlot);
            if (stack == null || stack.stackSize <= 0 || !(stack.getItem() instanceof ItemBlock)) {
                continue;
            }

            Block block = ((ItemBlock) stack.getItem()).getBlock();
            if (!BlockUtil.isInteractable(block) && BlockUtil.isSolid(block)) {
                blockCount += stack.stackSize;
            }
        }

        this.drawBlockCounter(blockCount);
    }

    @EventTarget
    public void onLeftClick(LeftClickMouseEvent event) {
        if (this.isEnabled()) {
            event.setCancelled(true);
        }
    }

    @EventTarget
    public void onRightClick(RightClickMouseEvent event) {
        if (this.isEnabled()) {
            event.setCancelled(true);
        }
    }

    @EventTarget
    public void onHitBlock(HitBlockEvent event) {
        if (this.isEnabled()) {
            event.setCancelled(true);
        }
    }

    // Remembers the requested slot while Scaffold retains hotbar control.
    @EventTarget
    public void onSwap(SwapItemEvent event) {
        if (!this.isEnabled()) {
            return;
        }

        this.previousHotbarSlot = event.setSlot(this.previousHotbarSlot);
        event.setCancelled(true);
    }

    @Override
    public void onEnabled() {
        this.previousHotbarSlot = mc.thePlayer != null
                ? mc.thePlayer.inventory.currentItem
                : -1;
        this.remainingStackBlocks = -1;
        this.placementDelayTicks = 0;
        this.placementYaw = -180.0F;
        this.placementPitch = 0.0F;
        this.hasPlacementRotation = false;
        this.towerPhase = 0;
        this.towerCycleCount = 0;
        this.tellyRotationActive = false;
        this.watchdog3PlaceDelay = 0;
        this.onGroundState = false;
        this.watchdog2Flag = false;
        this.timerTickCounter = 0;
        this.timerActive = false;
        if (mc.thePlayer != null) {
            this.headYaw = mc.thePlayer.rotationYaw - 150.0F;
        }
    }

    @Override
    public void onDisabled() {
        if (mc.thePlayer != null && this.previousHotbarSlot != -1) {
            mc.thePlayer.inventory.currentItem = this.previousHotbarSlot;
        }
        ((IAccessorMinecraft) mc).getTimer().timerSpeed = 1.0F;
        this.timerActive = false;
        this.timerTickCounter = 0;
    }

    private boolean isKeepYOnPressVisible() {
        return this.keepY.getValue() != KEEP_Y_NONE;
    }

    private static double targetDistanceSquared(BlockPos desiredPlacementBlock, BlockPos supportCandidate) {
        return supportCandidate.distanceSqToCenter(
                desiredPlacementBlock.getX() + 0.5,
                desiredPlacementBlock.getY() + 0.5,
                desiredPlacementBlock.getZ() + 0.5
        );
    }

    /** Advances the VANILLA Tower phase; every phase returns to the movement handler. */
    private void applyVanillaTowerMotion(int heightHundredths, StrafeEvent event) {
        switch (this.towerPhase) {
            case 0:
                if (mc.thePlayer.onGround) {
                    this.towerPhase = 1;
                    mc.thePlayer.motionY = -0.0784000015258789;
                }
                return;
            case 1:
                if (heightHundredths == 0 && PlayerUtil.isAirBelow()) {
                    this.keepYLevel = MathHelper.floor_double(mc.thePlayer.posY);
                    this.towerPhase = 2;
                    mc.thePlayer.motionY = 0.42F;
                    if (MoveUtil.isForwardPressed()) {
                        MoveUtil.setSpeed(MoveUtil.getSpeed(), MoveUtil.getMoveYaw());
                    } else {
                        MoveUtil.setSpeed(0.0);
                        event.setForward(0.0F);
                        event.setStrafe(0.0F);
                    }
                    return;
                } else {
                    this.towerPhase = 0;
                    return;
                }
            case 2:
                this.towerPhase = 3;
                mc.thePlayer.motionY = 0.75 - mc.thePlayer.posY % 1.0;
                return;
            case 3:
                this.towerPhase = 1;
                mc.thePlayer.motionY = 1.0 - mc.thePlayer.posY % 1.0;
                return;
            default:
                this.towerPhase = 0;
        }
    }

    /** Advances the EXTRA Tower phase, including edge positioning and the cycle pause. */
    private void applyExtraTowerMotion(int heightHundredths, StrafeEvent event) {
        switch (this.towerPhase) {
            case 0:
                if (mc.thePlayer.onGround) {
                    this.towerPhase = 1;
                    mc.thePlayer.motionY = -0.0784000015258789;
                }
                return;
            case 1:
                if (heightHundredths == 0 && PlayerUtil.isAirBelow()) {
                    this.keepYLevel = MathHelper.floor_double(mc.thePlayer.posY);
                    if (!MoveUtil.isForwardPressed()) {
                        this.towerCycleCount = 2;
                        MoveUtil.setSpeed(0.0);
                        event.setForward(0.0F);
                        event.setStrafe(0.0F);
                        EnumFacing towerFacing = this.facingFromYaw(MathHelper.wrapAngleTo180_float(this.placementYaw - 180.0F));
                        double edgeDistance = this.distanceToBlockEdge(towerFacing);
                        if (edgeDistance > 0.1) {
                            if (mc.thePlayer.onGround) {
                                Vec3i edgeDirection = towerFacing.getDirectionVec();
                                double approachDistance = Math.min(this.randomEdgeApproachDistance(), edgeDistance - 0.05);
                                double edgePadding = RandomUtil.nextDouble(0.02, 0.03);
                                AxisAlignedBB shiftedBounds = mc.thePlayer
                                        .getEntityBoundingBox()
                                        .offset(edgeDirection.getX() * (approachDistance - edgePadding), 0.0, edgeDirection.getZ() * (approachDistance - edgePadding));
                                if (mc.theWorld.getCollidingBoundingBoxes(mc.thePlayer, shiftedBounds).isEmpty()) {
                                    mc.thePlayer.motionY = -0.0784000015258789;
                                    mc.thePlayer.setPosition(
                                            shiftedBounds.minX + (shiftedBounds.maxX - shiftedBounds.minX) / 2.0,
                                            shiftedBounds.minY,
                                            shiftedBounds.minZ + (shiftedBounds.maxZ - shiftedBounds.minZ) / 2.0
                                    );
                                }
                                return;
                            }
                        } else {
                            this.towerPhase = 2;
                            this.pendingPlacementFace = towerFacing;
                            mc.thePlayer.motionY = 0.42F;
                        }
                        return;
                    } else {
                        this.towerPhase = 2;
                        this.towerCycleCount++;
                        mc.thePlayer.motionY = 0.42F;
                        MoveUtil.setSpeed(MoveUtil.getSpeed(), MoveUtil.getMoveYaw());
                        return;
                    }
                } else {
                    this.towerPhase = 0;
                    this.towerCycleCount = 0;
                    return;
                }
            case 2:
                this.towerPhase = 3;
                mc.thePlayer.motionY = mc.thePlayer.motionY - RandomUtil.nextDouble(0.00101, 0.00109);
                return;
            case 3:
                if (this.towerCycleCount >= 4) {
                    this.towerPhase = 4;
                    this.towerCycleCount = 0;
                } else {
                    this.towerPhase = 1;
                    mc.thePlayer.motionY = 1.0 - mc.thePlayer.posY % 1.0;
                }
                return;
            case 4:
                this.towerPhase = 5;
                return;
            case 5:
                if (!PlayerUtil.isAirBelow()) {
                    this.towerPhase = 0;
                } else {
                    this.towerPhase = 1;
                    mc.thePlayer.motionY -= 0.08;
                    mc.thePlayer.motionY *= 0.98F;
                    mc.thePlayer.motionY -= 0.08;
                    mc.thePlayer.motionY *= 0.98F;
                }
                return;
            default:
                this.towerPhase = 0;
                this.towerCycleCount = 0;
        }
    }

    /** Draws the current placeable-block count beside the crosshair. */
    private void drawBlockCounter(int blockCount) {
        HUD hud = (HUD) Myau.moduleManager.modules.get(HUD.class);
        float hudScale = hud.scale.getValue();
        GlStateManager.pushMatrix();
        GlStateManager.scale(hudScale, hudScale, 0.0F);
        GlStateManager.disableDepth();
        GlStateManager.enableBlend();
        GlStateManager.blendFunc(GL11.GL_SRC_ALPHA, GL11.GL_ONE_MINUS_SRC_ALPHA);

        FontRenderer fontRenderer = mc.fontRendererObj;
        String counterText = String.format("%d block%s left", blockCount, blockCount != 1 ? "s" : "");
        ScaledResolution resolution = new ScaledResolution(mc);
        float textX = (resolution.getScaledWidth() / 2.0F + fontRenderer.FONT_HEIGHT * 1.5F) / hudScale;
        float textY = resolution.getScaledHeight() / 2.0F / hudScale - fontRenderer.FONT_HEIGHT / 2.0F + 1.0F;
        int textColor = blockCount > 0 ? 0xFFFFFF : 0xFF5555;
        fontRenderer.drawString(counterText, textX, textY, textColor | 0xBF000000, hud.shadow.getValue());

        GlStateManager.disableBlend();
        GlStateManager.enableDepth();
        GlStateManager.popMatrix();
    }

    private static float[] rotationsFromDelta(double deltaX, double deltaY, double deltaZ) {
        double horizontalDistance = Math.sqrt(deltaX * deltaX + deltaZ * deltaZ);
        float yaw = (float) (Math.atan2(deltaZ, deltaX) * 180.0 / Math.PI) - 90.0F;
        float pitch = (float) (-(Math.atan2(deltaY, horizontalDistance) * 180.0 / Math.PI));
        return new float[]{yaw, pitch};
    }

    private static float snapToMouseSensitivity(float target, float previous) {
        float sensitivity = mc.gameSettings.mouseSensitivity * 0.6F + 0.2F;
        float gcd = sensitivity * sensitivity * sensitivity * 1.2F;
        if (gcd < 1.0E-4F) {
            return target;
        }
        return previous + Math.round((target - previous) / gcd) * gcd;
    }

    public static class BlockPlacementTarget {
        private final BlockPos position;
        private final EnumFacing face;

        public BlockPlacementTarget(BlockPos position, EnumFacing face) {
            this.position = position;
            this.face = face;
        }

        public BlockPos position() {
            return this.position;
        }

        public EnumFacing face() {
            return this.face;
        }
    }
}
