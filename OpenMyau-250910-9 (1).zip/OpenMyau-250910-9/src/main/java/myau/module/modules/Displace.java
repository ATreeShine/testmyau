package myau.module.modules;

import myau.Myau;
import myau.enums.BlinkModules;
import myau.event.EventTarget;
import myau.event.types.EventType;
import myau.event.types.Priority;
import myau.events.*;
import myau.mixin.IAccessorRenderManager;
import myau.module.Module;
import myau.property.properties.BooleanProperty;
import myau.property.properties.IntProperty;
import myau.property.properties.ModeProperty;
import myau.property.properties.TextProperty;
import myau.util.MoveUtil;
import myau.util.RotationUtil;
import myau.util.TeamUtil;
import net.minecraft.block.state.IBlockState;
import net.minecraft.client.Minecraft;
import net.minecraft.client.settings.KeyBinding;
import net.minecraft.enchantment.EnchantmentHelper;
import net.minecraft.entity.Entity;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.item.ItemStack;
import net.minecraft.network.play.client.C03PacketPlayer;
import net.minecraft.util.AxisAlignedBB;
import net.minecraft.util.BlockPos;
import net.minecraft.util.MathHelper;
import net.minecraft.util.Vec3;
import org.lwjgl.opengl.GL11;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Locale;
import java.util.Map;

public class Displace extends Module {
    private static final Minecraft mc = Minecraft.getMinecraft();
    private static final int DISPLACE_WINDOW_TICKS = 10;
    private static final int VOID_SCAN_DIRECTIONS = 32;
    private static final int VOID_SCAN_RINGS = 12;
    private static final int VOID_SCAN_DEPTH = 10;
    private static final double VOID_SCAN_STEP = 0.5D;
    private static final double DYNAMIC_SCAN_STEP = 0.5D;
    private static final double DYNAMIC_SCAN_DISTANCE = 6.0D;
    private static final double DYNAMIC_SCAN_SIDE_STEP = 0.45D;
    private static final double DYNAMIC_WALL_CHECK_STEP = 0.25D;
    private static final double DYNAMIC_COLLISION_INSET = 0.03D;
    private static final long ARROW_FADE_MS = 250L;
    private static final double ARROW_FORWARD_GAP = 0.24D;
    private static final double ARROW_BODY_LENGTH = 0.74D;
    private static final double ARROW_BODY_HALF_HEIGHT = 0.08D;
    private static final double ARROW_HEAD_BACKSET = 0.18D;
    private static final double ARROW_HEAD_LENGTH = 0.52D;
    private static final double ARROW_HEAD_HALF_HEIGHT = 0.30D;
    private static final double[] VOID_SCAN_X = new double[VOID_SCAN_DIRECTIONS];
    private static final double[] VOID_SCAN_Z = new double[VOID_SCAN_DIRECTIONS];
    private static final int DYNAMIC_ANGLE_STATIC = 0;
    private static final int DYNAMIC_ANGLE_DYNAMIC = 1;
    private static final int DIRECTION_LEFT = 0;
    private static final int ROTATION_PRIORITY = 6;

    public final ModeProperty dynamicAngle = new ModeProperty("dynamic-angle", 0, new String[]{"STATIC", "DYNAMIC"});
    public final IntProperty yawOffset = new IntProperty("yaw-offset", 90, 0, 180, this::isStaticAngle);
    public final IntProperty delay = new IntProperty("delay", 0, 0, 500);
    public final ModeProperty direction = new ModeProperty("direction", 0, new String[]{"LEFT", "RIGHT"}, this::isStaticAngle);
    public final BooleanProperty showDirection = new BooleanProperty("show-direction", true);
    public final BooleanProperty findVoid = new BooleanProperty("find-void", false, this::isStaticAngle);
    public final BooleanProperty blink = new BooleanProperty("blink", false);
    public final BooleanProperty ignoreTeammates = new BooleanProperty("ignore-teammates", true);
    public final BooleanProperty hasKnockback = new BooleanProperty("has-knockback", false);
    public final BooleanProperty itemWhitelistToggle = new BooleanProperty("item-whitelist", false);
    public final TextProperty itemWhitelist = new TextProperty("whitelisted-items", "", this.itemWhitelistToggle::getValue);

    private boolean displaceThisTick = false;
    private boolean active = false;
    private boolean hasKB = false;
    private boolean compensateNextTick = false;
    private boolean displaceLeft = false;
    private boolean wasDisplacingLastTick = false;
    private boolean releaseBlinkNextGameTick = false;
    private Float dynamicVoidYaw = null;
    private Float renderDisplaceYaw = null;
    private EntityPlayer renderTarget = null;
    private Float fadingDisplaceYaw = null;
    private EntityPlayer fadingTarget = null;
    private long arrowFadeStartMs = 0L;
    private Float lastRenderedDisplaceYaw = null;
    private EntityPlayer lastRenderedTarget = null;
    private long lastRenderedArrowMs = 0L;
    private int tickCounter;
    private final Map<Integer, Integer> targetWindowStartTicks = new HashMap<Integer, Integer>();

    static {
        for (int i = 0; i < VOID_SCAN_DIRECTIONS; i++) {
            double angle = Math.PI * 2.0D * (double) i / (double) VOID_SCAN_DIRECTIONS;
            VOID_SCAN_X[i] = Math.cos(angle);
            VOID_SCAN_Z[i] = Math.sin(angle);
        }
    }

    public Displace() {
        super("Displace", false);
    }

    @Override
    public String[] getSuffix() {
        return new String[]{this.delay.getValue() + "ms"};
    }

    @Override
    public void onEnabled() {
        this.displaceThisTick = false;
        this.active = false;
        this.hasKB = false;
        this.compensateNextTick = false;
        this.wasDisplacingLastTick = false;
        this.releaseBlinkNextGameTick = false;
        this.dynamicVoidYaw = null;
        this.renderDisplaceYaw = null;
        this.renderTarget = null;
        this.clearArrowState();
        this.tickCounter = 0;
        this.targetWindowStartTicks.clear();
        this.releaseBlink();
    }

    @Override
    public void onDisabled() {
        this.active = false;
        this.compensateNextTick = false;
        this.wasDisplacingLastTick = false;
        this.releaseBlinkNextGameTick = false;
        this.dynamicVoidYaw = null;
        this.renderDisplaceYaw = null;
        this.renderTarget = null;
        this.clearArrowState();
        this.targetWindowStartTicks.clear();
        this.releaseBlink();
    }

    private boolean isStaticAngle() {
        return this.dynamicAngle.getValue() != DYNAMIC_ANGLE_DYNAMIC;
    }

    private static int msToTicks(double ms) {
        if (ms <= 0.0D) {
            return 0;
        }
        return (int) Math.ceil(ms / 50.0D);
    }

    private boolean anyMovementKey() {
        return mc.gameSettings.keyBindForward.isKeyDown()
                || mc.gameSettings.keyBindBack.isKeyDown()
                || mc.gameSettings.keyBindLeft.isKeyDown()
                || mc.gameSettings.keyBindRight.isKeyDown();
    }

    private boolean isDynamicAngle() {
        return this.dynamicAngle.getValue() == DYNAMIC_ANGLE_DYNAMIC;
    }

    private boolean isValidPlayer(EntityPlayer player) {
        if (mc.thePlayer == null || player == null || player == mc.thePlayer || player.isDead || player.deathTime != 0) {
            return false;
        }
        if (TeamUtil.isFriend(player) || TeamUtil.isBot(player)) {
            return false;
        }
        return !this.ignoreTeammates.getValue() || !TeamUtil.isSameTeam(player);
    }

    private EntityPlayer findClosestTarget() {
        if (mc.theWorld == null) {
            return null;
        }

        EntityPlayer closest = null;
        double closestDistanceSq = Double.MAX_VALUE;

        for (EntityPlayer player : mc.theWorld.playerEntities) {
            if (!this.isValidPlayer(player)) {
                continue;
            }

            double distance = RotationUtil.distanceToEntity(player);
            double distanceSq = distance * distance;
            if (distanceSq > 9.0D) {
                continue;
            }
            if (distanceSq < closestDistanceSq) {
                closestDistanceSq = distanceSq;
                closest = player;
            }
        }

        return closest;
    }

    private boolean matchesWhitelist(ItemStack stack) {
        if (stack == null || stack.getItem() == null) {
            return false;
        }

        String raw = this.itemWhitelist.getValue();
        if (raw == null || raw.trim().isEmpty()) {
            return false;
        }

        String registryName = stack.getItem().getRegistryName();
        String displayName = stack.getDisplayName();
        String unlocalizedName = stack.getUnlocalizedName();

        for (String token : raw.split(",")) {
            String needle = token.trim().toLowerCase(Locale.ROOT);
            if (needle.isEmpty()) {
                continue;
            }
            if (registryName != null && (registryName.equalsIgnoreCase(token.trim())
                    || registryName.toLowerCase(Locale.ROOT).endsWith(":" + needle)
                    || registryName.toLowerCase(Locale.ROOT).contains(needle))) {
                return true;
            }
            if (displayName != null && displayName.toLowerCase(Locale.ROOT).contains(needle)) {
                return true;
            }
            if (unlocalizedName != null && unlocalizedName.toLowerCase(Locale.ROOT).contains(needle)) {
                return true;
            }
        }
        return false;
    }

    private Float findStaticVoidYaw(EntityPlayer target) {
        if (target == null || mc.thePlayer == null || mc.theWorld == null) {
            return null;
        }

        double bestX = 0.0D;
        double bestZ = 0.0D;
        double bestScore = Double.MAX_VALUE;

        for (int ring = 1; ring <= VOID_SCAN_RINGS; ring++) {
            double radius = (double) ring * VOID_SCAN_STEP;
            boolean foundInRing = false;

            for (int i = 0; i < VOID_SCAN_DIRECTIONS; i++) {
                double x = target.posX + VOID_SCAN_X[i] * radius;
                double z = target.posZ + VOID_SCAN_Z[i] * radius;
                if (!this.isVoidColumn(x, target.posY, z)) {
                    continue;
                }

                double playerDx = x - mc.thePlayer.posX;
                double playerDz = z - mc.thePlayer.posZ;
                double playerDistSq = playerDx * playerDx + playerDz * playerDz;
                double score = radius * radius * 1000.0D + playerDistSq;
                if (score < bestScore) {
                    bestScore = score;
                    bestX = x;
                    bestZ = z;
                    foundInRing = true;
                }
            }

            if (foundInRing) {
                break;
            }
        }

        if (bestScore == Double.MAX_VALUE) {
            return null;
        }

        this.updateDisplaceSide(target, bestX, bestZ);

        double dx = bestX - target.posX;
        double dz = bestZ - target.posZ;
        double dist = Math.sqrt(dx * dx + dz * dz);
        if (dist < 0.001D) {
            return null;
        }

        double aimRadius = Math.min(dist, Math.max(0.35D, (double) target.width * 0.5D + 0.15D));
        double aimX = target.posX + dx / dist * aimRadius;
        double aimZ = target.posZ + dz / dist * aimRadius;
        Vec3 eyes = mc.thePlayer.getPositionEyes(1.0F);
        return rotationsFromEye(eyes, aimX, target.posY + (double) target.getEyeHeight() * 0.5D, aimZ)[0];
    }

    private Float findDynamicVoidYaw(EntityPlayer target) {
        if (target == null || mc.thePlayer == null || mc.theWorld == null) {
            return null;
        }

        double bestForwardX = 0.0D;
        double bestForwardZ = 0.0D;
        double bestScore = 0.0D;

        for (int i = 0; i < VOID_SCAN_DIRECTIONS; i++) {
            double forwardX = VOID_SCAN_X[i];
            double forwardZ = VOID_SCAN_Z[i];
            double score = this.scoreVoidPath(target, forwardX, forwardZ);

            if (score > bestScore) {
                bestScore = score;
                bestForwardX = forwardX;
                bestForwardZ = forwardZ;
            }
        }

        if (bestScore <= 0.0D) {
            return null;
        }

        this.updateDisplaceSide(target, target.posX + bestForwardX, target.posZ + bestForwardZ);
        return this.yawFromForward(bestForwardX, bestForwardZ);
    }

    private float yawFromForward(double forwardX, double forwardZ) {
        return (float) (Math.toDegrees(Math.atan2(forwardZ, forwardX)) - 90.0D);
    }

    private double scoreVoidPath(EntityPlayer target, double forwardX, double forwardZ) {
        double sideX = -forwardZ;
        double sideZ = forwardX;
        double score = 0.0D;
        double checkedForward = 0.0D;
        int consecutiveCenterVoid = 0;
        AxisAlignedBB baseCollisionBox = target.getEntityBoundingBox().contract(DYNAMIC_COLLISION_INSET, 0.0D, DYNAMIC_COLLISION_INSET);

        for (int step = 1; step <= (int) (DYNAMIC_SCAN_DISTANCE / DYNAMIC_SCAN_STEP); step++) {
            double forward = (double) step * DYNAMIC_SCAN_STEP;
            if (!this.isDynamicPathClear(target, baseCollisionBox, forwardX, forwardZ, checkedForward, forward)) {
                break;
            }
            checkedForward = forward;

            boolean centerVoid = false;

            for (int side = -1; side <= 1; side++) {
                double sideOffset = (double) side * DYNAMIC_SCAN_SIDE_STEP;
                double x = target.posX + forwardX * forward + sideX * sideOffset;
                double z = target.posZ + forwardZ * forward + sideZ * sideOffset;
                if (this.isVoidColumn(x, target.posY, z)) {
                    double laneWeight = side == 0 ? 1.4D : 1.0D;
                    score += laneWeight * (DYNAMIC_SCAN_DISTANCE + DYNAMIC_SCAN_STEP - forward);
                    centerVoid |= side == 0;
                }
            }

            if (centerVoid) {
                consecutiveCenterVoid++;
                score += consecutiveCenterVoid * 2.0D;
            } else {
                consecutiveCenterVoid = 0;
            }
        }

        return score;
    }

    private boolean isDynamicPathClear(EntityPlayer target, AxisAlignedBB baseCollisionBox, double forwardX, double forwardZ, double fromForward, double toForward) {
        for (double forward = fromForward + DYNAMIC_WALL_CHECK_STEP; forward <= toForward + 1.0E-4D; forward += DYNAMIC_WALL_CHECK_STEP) {
            AxisAlignedBB checkBox = baseCollisionBox.offset(forwardX * forward, 0.0D, forwardZ * forward);
            if (this.hasBlockCollision(target, checkBox)) {
                return false;
            }
        }
        return true;
    }

    private boolean hasBlockCollision(EntityPlayer target, AxisAlignedBB box) {
        int minX = MathHelper.floor_double(box.minX);
        int maxX = MathHelper.floor_double(box.maxX + 1.0D);
        int minY = MathHelper.floor_double(box.minY);
        int maxY = MathHelper.floor_double(box.maxY + 1.0D);
        int minZ = MathHelper.floor_double(box.minZ);
        int maxZ = MathHelper.floor_double(box.maxZ + 1.0D);

        List<AxisAlignedBB> collisions = new ArrayList<AxisAlignedBB>();
        BlockPos.MutableBlockPos blockPos = new BlockPos.MutableBlockPos();
        for (int blockX = minX; blockX < maxX; blockX++) {
            for (int blockZ = minZ; blockZ < maxZ; blockZ++) {
                if (!mc.theWorld.isBlockLoaded(blockPos.set(blockX, 64, blockZ))) {
                    return true;
                }

                for (int blockY = minY; blockY < maxY; blockY++) {
                    if (blockY < 0 || blockY >= 256) {
                        return true;
                    }

                    blockPos.set(blockX, blockY, blockZ);
                    IBlockState state = mc.theWorld.getBlockState(blockPos);
                    state.getBlock().addCollisionBoxesToList(mc.theWorld, blockPos, state, box, collisions, target);
                    if (!collisions.isEmpty()) {
                        return true;
                    }
                }
            }
        }
        return false;
    }

    private boolean isVoidColumn(double x, double y, double z) {
        int blockX = MathHelper.floor_double(x);
        int blockZ = MathHelper.floor_double(z);
        int startY = MathHelper.floor_double(y) - 1;
        int endY = Math.max(0, startY - VOID_SCAN_DEPTH);

        for (int blockY = startY; blockY >= endY; blockY--) {
            if (!mc.theWorld.isAirBlock(new BlockPos(blockX, blockY, blockZ))) {
                return false;
            }
        }
        return true;
    }

    private void updateDisplaceSide(EntityPlayer target, double voidX, double voidZ) {
        double targetDx = target.posX - mc.thePlayer.posX;
        double targetDz = target.posZ - mc.thePlayer.posZ;
        double voidDx = voidX - mc.thePlayer.posX;
        double voidDz = voidZ - mc.thePlayer.posZ;
        double cross = targetDx * voidDz - targetDz * voidDx;
        this.displaceLeft = cross < 0.0D;
    }

    private float getFixedDisplaceYaw(float serverYaw) {
        float offset = this.yawOffset.getValue();
        return this.displaceLeft ? serverYaw - offset : serverYaw + offset;
    }

    private void clearActiveState() {
        this.startArrowFade();
        this.active = false;
        this.displaceThisTick = false;
        this.compensateNextTick = false;
        this.wasDisplacingLastTick = false;
        this.dynamicVoidYaw = null;
        this.renderDisplaceYaw = null;
        this.renderTarget = null;
    }

    private void clearFadingArrow() {
        this.fadingDisplaceYaw = null;
        this.fadingTarget = null;
        this.arrowFadeStartMs = 0L;
    }

    private void clearArrowState() {
        this.clearFadingArrow();
        this.lastRenderedDisplaceYaw = null;
        this.lastRenderedTarget = null;
        this.lastRenderedArrowMs = 0L;
    }

    private void startArrowFade() {
        long nowMs = System.currentTimeMillis();
        if (this.lastRenderedDisplaceYaw != null && this.lastRenderedTarget != null && !this.lastRenderedTarget.isDead
                && nowMs - this.lastRenderedArrowMs <= ARROW_FADE_MS) {
            this.fadingDisplaceYaw = this.lastRenderedDisplaceYaw;
            this.fadingTarget = this.lastRenderedTarget;
            this.arrowFadeStartMs = nowMs;
        }
        this.lastRenderedDisplaceYaw = null;
        this.lastRenderedTarget = null;
        this.lastRenderedArrowMs = 0L;
    }

    private void pruneTargetDelayStates() {
        if (mc.theWorld == null) {
            this.targetWindowStartTicks.clear();
            return;
        }

        Iterator<Map.Entry<Integer, Integer>> iterator = this.targetWindowStartTicks.entrySet().iterator();
        while (iterator.hasNext()) {
            Map.Entry<Integer, Integer> entry = iterator.next();
            Entity entity = mc.theWorld.getEntityByID(entry.getKey());
            if (!(entity instanceof EntityPlayer) || entity.isDead || ((EntityPlayer) entity).deathTime != 0) {
                iterator.remove();
            }
        }
    }

    private boolean shouldDisplaceInCurrentWindow(EntityPlayer target, int currentTick) {
        if (target == null) {
            return true;
        }

        int targetId = target.getEntityId();
        Integer windowStartTick = this.targetWindowStartTicks.get(targetId);
        if (windowStartTick == null || currentTick - windowStartTick >= DISPLACE_WINDOW_TICKS) {
            this.targetWindowStartTicks.put(targetId, currentTick);
            return true;
        }

        int delayTicks = msToTicks(this.delay.getValue());
        if (delayTicks <= 0) {
            return true;
        }

        int elapsed = currentTick - windowStartTick;
        return elapsed >= delayTicks;
    }

    private void releaseBlink() {
        if (Myau.blinkManager.getBlinkingModule() == BlinkModules.DISPLACE) {
            Myau.blinkManager.setBlinkState(false, BlinkModules.DISPLACE);
        }
    }

    @EventTarget(Priority.HIGHEST)
    public void onTick(TickEvent event) {
        if (!this.isEnabled() || event.getType() != EventType.PRE) {
            return;
        }
        if (this.releaseBlinkNextGameTick) {
            this.releaseBlink();
            this.releaseBlinkNextGameTick = false;
        }
    }

    @EventTarget
    public void onRender3D(Render3DEvent event) {
        if (!this.isEnabled() || mc.thePlayer == null || mc.theWorld == null || !this.showDirection.getValue()) {
            this.clearArrowState();
            return;
        }

        long nowMs = System.currentTimeMillis();
        boolean activeArrow = this.active && this.renderDisplaceYaw != null && this.renderTarget != null && !this.renderTarget.isDead;
        Float arrowYaw = this.renderDisplaceYaw;
        EntityPlayer arrowTarget = this.renderTarget;
        float alpha = 1.0F;

        if (activeArrow) {
            this.clearFadingArrow();
        } else {
            if (this.fadingDisplaceYaw == null || this.fadingTarget == null || this.fadingTarget.isDead) {
                this.clearFadingArrow();
                return;
            }

            long fadeElapsedMs = nowMs - this.arrowFadeStartMs;
            if (fadeElapsedMs >= ARROW_FADE_MS) {
                this.clearFadingArrow();
                return;
            }

            arrowYaw = this.fadingDisplaceYaw;
            arrowTarget = this.fadingTarget;
            alpha = 1.0F - (float) fadeElapsedMs / (float) ARROW_FADE_MS;
        }

        float partialTicks = event.getPartialTicks();
        double centerX = arrowTarget.lastTickPosX + (arrowTarget.posX - arrowTarget.lastTickPosX) * partialTicks;
        double centerY = arrowTarget.lastTickPosY + (arrowTarget.posY - arrowTarget.lastTickPosY) * partialTicks
                + (double) arrowTarget.height * 0.5D;
        double centerZ = arrowTarget.lastTickPosZ + (arrowTarget.posZ - arrowTarget.lastTickPosZ) * partialTicks;

        double yawRad = Math.toRadians(arrowYaw);
        double forwardX = -Math.sin(yawRad);
        double forwardZ = Math.cos(yawRad);

        double baseOffset = (double) arrowTarget.width * 0.5D + ARROW_FORWARD_GAP;
        double tailX = centerX + forwardX * baseOffset;
        double tailZ = centerZ + forwardZ * baseOffset;
        double bodyEndX = tailX + forwardX * ARROW_BODY_LENGTH;
        double bodyEndZ = tailZ + forwardZ * ARROW_BODY_LENGTH;
        double headBackX = tailX + forwardX * (ARROW_BODY_LENGTH - ARROW_HEAD_BACKSET);
        double headBackZ = tailZ + forwardZ * (ARROW_BODY_LENGTH - ARROW_HEAD_BACKSET);
        double tipX = bodyEndX + forwardX * ARROW_HEAD_LENGTH;
        double tipZ = bodyEndZ + forwardZ * ARROW_HEAD_LENGTH;

        IAccessorRenderManager renderManager = (IAccessorRenderManager) mc.getRenderManager();
        double viewerX = renderManager.getRenderPosX();
        double viewerY = renderManager.getRenderPosY();
        double viewerZ = renderManager.getRenderPosZ();

        GL11.glPushMatrix();
        GL11.glPushAttrib(GL11.GL_ENABLE_BIT | GL11.GL_COLOR_BUFFER_BIT | GL11.GL_LINE_BIT | GL11.GL_DEPTH_BUFFER_BIT | GL11.GL_CURRENT_BIT);
        GL11.glEnable(GL11.GL_BLEND);
        GL11.glBlendFunc(GL11.GL_SRC_ALPHA, GL11.GL_ONE_MINUS_SRC_ALPHA);
        GL11.glDisable(GL11.GL_TEXTURE_2D);
        GL11.glDisable(GL11.GL_LIGHTING);
        GL11.glDisable(GL11.GL_DEPTH_TEST);
        GL11.glDisable(GL11.GL_CULL_FACE);
        GL11.glDepthMask(false);
        GL11.glEnable(GL11.GL_LINE_SMOOTH);

        GL11.glColor4f(1.0F, 1.0F, 1.0F, 0.82F * alpha);
        GL11.glBegin(GL11.GL_TRIANGLES);
        GL11.glVertex3d(tailX - viewerX, centerY - viewerY, tailZ - viewerZ);
        this.arrowVertex(bodyEndX, centerY, bodyEndZ, -ARROW_BODY_HALF_HEIGHT, viewerX, viewerY, viewerZ);
        this.arrowVertex(bodyEndX, centerY, bodyEndZ, ARROW_BODY_HALF_HEIGHT, viewerX, viewerY, viewerZ);
        this.arrowVertex(bodyEndX, centerY, bodyEndZ, -ARROW_BODY_HALF_HEIGHT, viewerX, viewerY, viewerZ);
        this.arrowVertex(headBackX, centerY, headBackZ, -ARROW_HEAD_HALF_HEIGHT, viewerX, viewerY, viewerZ);
        GL11.glVertex3d(tipX - viewerX, centerY - viewerY, tipZ - viewerZ);
        this.arrowVertex(bodyEndX, centerY, bodyEndZ, -ARROW_BODY_HALF_HEIGHT, viewerX, viewerY, viewerZ);
        GL11.glVertex3d(tipX - viewerX, centerY - viewerY, tipZ - viewerZ);
        this.arrowVertex(bodyEndX, centerY, bodyEndZ, ARROW_BODY_HALF_HEIGHT, viewerX, viewerY, viewerZ);
        this.arrowVertex(bodyEndX, centerY, bodyEndZ, ARROW_BODY_HALF_HEIGHT, viewerX, viewerY, viewerZ);
        GL11.glVertex3d(tipX - viewerX, centerY - viewerY, tipZ - viewerZ);
        this.arrowVertex(headBackX, centerY, headBackZ, ARROW_HEAD_HALF_HEIGHT, viewerX, viewerY, viewerZ);
        GL11.glEnd();

        GL11.glLineWidth(2.0F);
        GL11.glColor4f(0.0F, 0.0F, 0.0F, 0.95F * alpha);
        GL11.glBegin(GL11.GL_LINE_LOOP);
        GL11.glVertex3d(tailX - viewerX, centerY - viewerY, tailZ - viewerZ);
        this.arrowVertex(bodyEndX, centerY, bodyEndZ, -ARROW_BODY_HALF_HEIGHT, viewerX, viewerY, viewerZ);
        this.arrowVertex(headBackX, centerY, headBackZ, -ARROW_HEAD_HALF_HEIGHT, viewerX, viewerY, viewerZ);
        GL11.glVertex3d(tipX - viewerX, centerY - viewerY, tipZ - viewerZ);
        this.arrowVertex(headBackX, centerY, headBackZ, ARROW_HEAD_HALF_HEIGHT, viewerX, viewerY, viewerZ);
        this.arrowVertex(bodyEndX, centerY, bodyEndZ, ARROW_BODY_HALF_HEIGHT, viewerX, viewerY, viewerZ);
        GL11.glEnd();

        GL11.glPopAttrib();
        GL11.glPopMatrix();

        if (activeArrow) {
            this.lastRenderedDisplaceYaw = arrowYaw;
            this.lastRenderedTarget = arrowTarget;
            this.lastRenderedArrowMs = nowMs;
        }
    }

    private void arrowVertex(double x, double y, double z, double verticalOffset, double viewerX, double viewerY, double viewerZ) {
        GL11.glVertex3d(
                x - viewerX,
                y + verticalOffset - viewerY,
                z - viewerZ
        );
    }

    @EventTarget(Priority.LOWEST)
    public void onMoveInput(MoveInputEvent event) {
        if (!this.isEnabled() || !this.active) {
            this.compensateNextTick = false;
            return;
        }

        if (this.displaceThisTick && this.renderDisplaceYaw != null && MoveUtil.isForwardPressed()) {
            MoveUtil.fixStrafe(this.renderDisplaceYaw);
        }

        if (this.compensateNextTick && !this.displaceThisTick) {
            this.compensateNextTick = false;
            if (this.displaceLeft) {
                mc.thePlayer.movementInput.moveStrafe = -1;
            } else {
                mc.thePlayer.movementInput.moveStrafe = 1;
            }
            return;
        }

        if (!this.displaceThisTick || this.hasKB) {
            return;
        }
        if (!this.anyMovementKey()) {
            return;
        }

        mc.thePlayer.movementInput.moveForward = 1;
        this.compensateNextTick = true;
    }

    @EventTarget(Priority.HIGH)
    public void onPacket(PacketEvent event) {
        if (!this.isEnabled() || event.getType() != EventType.SEND) {
            return;
        }
        if (!this.blink.getValue() || !this.active || !this.displaceThisTick || this.releaseBlinkNextGameTick) {
            return;
        }
        if (!(event.getPacket() instanceof C03PacketPlayer)) {
            return;
        }
        if (Myau.blinkManager.getBlinkingModule() != BlinkModules.NONE) {
            return;
        }

        Myau.blinkManager.setBlinkState(true, BlinkModules.DISPLACE);
        this.releaseBlinkNextGameTick = true;
    }

    @EventTarget(Priority.LOWEST)
    public void onUpdate(UpdateEvent event) {
        if (!this.isEnabled() || event.getType() != EventType.PRE) {
            return;
        }

        if (mc.thePlayer == null || mc.theWorld == null) {
            this.clearActiveState();
            return;
        }

        this.tickCounter++;
        int currentTick = this.tickCounter;
        this.pruneTargetDelayStates();

        boolean passesItemCondition = true;
        if (this.hasKnockback.getValue() || this.itemWhitelistToggle.getValue()) {
            boolean kbPass = !this.hasKnockback.getValue() || EnchantmentHelper.getKnockbackModifier(mc.thePlayer) > 0;
            boolean wlPass = !this.itemWhitelistToggle.getValue() || this.matchesWhitelist(mc.thePlayer.getHeldItem());
            passesItemCondition = kbPass || wlPass;
        }
        if (!passesItemCondition) {
            this.clearActiveState();
            return;
        }

        EntityPlayer target = null;
        KillAura killAura = (KillAura) Myau.moduleManager.modules.get(KillAura.class);
        boolean attacking = mc.gameSettings.keyBindAttack.isKeyDown()
                || (killAura != null && killAura.isEnabled() && killAura.getTarget() != null);
        if (attacking) {
            target = this.findClosestTarget();
        }

        boolean hasKBEnchant = EnchantmentHelper.getKnockbackModifier(mc.thePlayer) > 0;
        this.active = target != null && (hasKBEnchant || this.anyMovementKey());
        if (!this.active) {
            this.clearActiveState();
            return;
        }

        this.dynamicVoidYaw = this.isDynamicAngle()
                ? this.findDynamicVoidYaw(target)
                : this.findVoid.getValue() ? this.findStaticVoidYaw(target) : null;
        if (this.dynamicVoidYaw == null && !this.isDynamicAngle()) {
            this.displaceLeft = this.direction.getValue() == DIRECTION_LEFT;
        }
        this.renderDisplaceYaw = this.dynamicVoidYaw != null ? this.dynamicVoidYaw : this.isDynamicAngle() ? null : this.getFixedDisplaceYaw(event.getYaw());
        this.renderTarget = this.renderDisplaceYaw != null ? target : null;
        if (this.renderDisplaceYaw == null) {
            this.clearActiveState();
            return;
        }

        this.hasKB = hasKBEnchant;
        this.displaceThisTick = !this.displaceThisTick;
        if (this.displaceThisTick && !this.shouldDisplaceInCurrentWindow(target, currentTick)) {
            this.startArrowFade();
            this.displaceThisTick = false;
            this.compensateNextTick = false;
            this.wasDisplacingLastTick = false;
            this.dynamicVoidYaw = null;
            this.renderDisplaceYaw = null;
            this.renderTarget = null;
            return;
        }

        if (!this.displaceThisTick && this.wasDisplacingLastTick) {
            int key = mc.gameSettings.keyBindAttack.getKeyCode();
            if (key != 0) {
                KeyBinding.onTick(key);
            }
        }

        this.wasDisplacingLastTick = this.displaceThisTick;

        if (!this.displaceThisTick || this.renderDisplaceYaw == null) {
            return;
        }

        event.setRotation(this.renderDisplaceYaw, event.getPitch(), ROTATION_PRIORITY);
        event.setPervRotation(this.renderDisplaceYaw, ROTATION_PRIORITY);
    }

    private static float[] rotationsFromEye(Vec3 eye, double tx, double ty, double tz) {
        double dx = tx - eye.xCoord;
        double dy = ty - eye.yCoord;
        double dz = tz - eye.zCoord;
        double dist = Math.sqrt(dx * dx + dz * dz);
        float yaw = (float) Math.toDegrees(Math.atan2(dz, dx)) - 90.0F;
        float pitch = (float) -Math.toDegrees(Math.atan2(dy, dist));
        return new float[]{yaw, pitch};
    }
}
