package myau.module.modules;

import myau.event.EventTarget;
import myau.event.types.EventType;
import myau.event.types.Priority;
import myau.events.*;
import myau.mixin.IAccessorMinecraft;
import myau.module.Module;
import myau.property.properties.BooleanProperty;
import myau.property.properties.FloatProperty;
import myau.property.properties.ModeProperty;
import myau.util.*;
import net.minecraft.client.Minecraft;
import net.minecraft.item.ItemBlock;
import net.minecraft.item.ItemStack;
import net.minecraft.network.play.client.C0APacketAnimation;
import net.minecraft.util.*;

public class Scaff2 extends Module {
    private static final Minecraft mc = Minecraft.getMinecraft();

    private static final String TEXT_SCAFFOLD = "Scaffold2";
    private static final String TEXT_ROTATIONS = "Rotations";
    private static final String TEXT_HITVEC = "HitVec";
    private static final String TEXT_BACKWARD = "Backward";
    private static final String TEXT_OFFSET = "Offset";
    private static final String TEXT_RAYCAST = "Raycast";
    private static final String TEXT_RAYCAST2 = "Raycast2";
    private static final String TEXT_ROTATION_SPEED = "Rotation Speed";
    private static final String TEXT_FAST_MODE = "Fast Mode";
    private static final String TEXT_DISABLED = "Disabled";
    private static final String TEXT_TELLY = "Telly";
    private static final String TEXT_WATCHDOG = "Watchdog";
    private static final String TEXT_WATCHDOG2 = "Watchdog2";
    private static final String TEXT_WATCHDOG3 = "Watchdog3";
    private static final String TEXT_TELLY_RMB = "Telly RMB";
    private static final String TEXT_KEEP_Y = "Keep Y";
    private static final String TEXT_TOWER = "Tower";
    private static final String TEXT_WATCHDOG_LOW = "Watchdog Low";
    private static final String TEXT_BLOCK_COUNT = "Block Count";
    private static final String TEXT_SILENT_SWING = "Silent Swing";
    private static final String TEXT_SNEAK = "Sneak";
    private static final String TEXT_SNEAK_DELAY = "Sneak Delay";
    private static final String TEXT_TIMER_TICKS = "Timer Ticks";

    private int keepYLevel;
    private int lastSlot = -1;
    private int placeDelay;
    private int timerTickCounter;
    private int selectedSlot = -1;
    private float currentYaw;
    private float currentPitch;
    private float lastYaw;
    private float lastPitch;
    private float headYaw;
    private boolean rotationSuccess;
    private boolean rotationSkip;
    private boolean onGroundState;
    private boolean rmbState;
    private boolean timerActive;
    private boolean watchdog2Flag;
    private final float[] rotationValues = new float[2];
    private final float[] yawOffsets = new float[]{0.0f, -1.0f, 1.0f, -2.0f, 2.0f, -3.0f, 3.0f, -4.0f, 4.0f, -5.0f, 5.0f, -6.0f, 6.0f, -7.0f, 7.0f, -8.0f, 8.0f, -9.0f, 9.0f, -10.0f, 10.0f, -11.0f, 11.0f, -12.0f, 12.0f, -13.0f, 13.0f, -14.0f, 14.0f, -15.0f, 15.0f, -16.0f, 16.0f, -17.0f, 17.0f, -18.0f, 18.0f, -19.0f, 19.0f, -20.0f, 20.0f, -22.0f, 22.0f, -24.0f, 24.0f, -26.0f, 26.0f, -28.0f, 28.0f, -30.0f, 30.0f, -32.0f, 32.0f, -34.0f, 34.0f, -36.0f, 36.0f, -38.0f, 38.0f, -40.0f, 40.0f, -42.0f, 42.0f, -44.0f, 44.0f, -46.0f, 46.0f, -48.0f, 48.0f, -50.0f, 50.0f, -52.0f, 52.0f, -54.0f, 54.0f, -56.0f, 56.0f, -58.0f, 58.0f, -60.0f, 60.0f, -62.0f, 62.0f, -64.0f, 64.0f, -66.0f, 66.0f, -68.0f, 68.0f, -70.0f, 70.0f, -72.0f, 72.0f, -74.0f, 74.0f, -76.0f, 76.0f, -78.0f, 78.0f, -80.0f, 80.0f, -82.0f, 82.0f, -84.0f, 84.0f, -86.0f, 86.0f, -88.0f, 88.0f, -90.0f, 90.0f, -92.0f, 92.0f, -94.0f, 94.0f, -96.0f, 96.0f, -98.0f, 98.0f, -100.0f, 100.0f, -102.0f, 102.0f, -104.0f, 104.0f, -106.0f, 106.0f, -108.0f, 108.0f, -110.0f, 110.0f, -112.0f, 112.0f, -114.0f, 114.0f, -116.0f, 116.0f, -118.0f, 118.0f, -120.0f, 120.0f, -122.0f, 122.0f, -124.0f, 124.0f, -126.0f, 126.0f, -128.0f, 128.0f, -130.0f, 130.0f, -132.0f, 132.0f, -134.0f, 134.0f, -136.0f, 136.0f, -138.0f, 138.0f, -140.0f, 140.0f, -142.0f, 142.0f, -144.0f, 144.0f, -146.0f, 146.0f, -148.0f, 148.0f, -150.0f, 150.0f, -152.0f, 152.0f, -154.0f, 154.0f, -156.0f, 156.0f, -158.0f, 158.0f, -160.0f, 160.0f, -162.0f, 162.0f, -164.0f, 164.0f, -166.0f, 166.0f, -168.0f, 168.0f, -170.0f, 170.0f, -172.0f, 172.0f, -174.0f, 174.0f, -176.0f, 176.0f, -178.0f, 178.0f, -180.0f, 180.0f};
    private final float[] pitchOffsets = new float[]{0.0f, -1.0f, 1.0f, -2.0f, 2.0f, -3.0f, 3.0f, -4.0f, 4.0f, -5.0f, 5.0f, -6.0f, 6.0f, -7.0f, 7.0f, -8.0f, 8.0f, -9.0f, 9.0f, -10.0f, 10.0f, -11.0f, 11.0f, -12.0f, 12.0f, -13.0f, 13.0f, -14.0f, 14.0f, -15.0f, 15.0f, -16.0f, 16.0f, -17.0f, 17.0f, -18.0f, 18.0f, -19.0f, 19.0f, -20.0f, 20.0f, -22.0f, 22.0f, -24.0f, 24.0f, -26.0f, 26.0f, -28.0f, 28.0f, -30.0f, 30.0f, -32.0f, 32.0f, -34.0f, 34.0f, -36.0f, 36.0f, -38.0f, 38.0f, -40.0f, 40.0f, -42.0f, 42.0f, -44.0f, 44.0f, -46.0f, 46.0f, -48.0f, 48.0f, -50.0f, 50.0f, -52.0f, 52.0f, -54.0f, 54.0f, -56.0f, 56.0f, -58.0f, 58.0f, -60.0f, 60.0f, -62.0f, 62.0f, -64.0f, 64.0f, -66.0f, 66.0f, -68.0f, 68.0f, -70.0f, 70.0f, -72.0f, 72.0f, -74.0f, 74.0f, -76.0f, 76.0f, -78.0f, 78.0f, -80.0f, 80.0f, -82.0f, 82.0f, -84.0f, 84.0f, -86.0f, 86.0f, -88.0f, 88.0f, -90.0f, 90.0f};

    public final ModeProperty rotations = new ModeProperty(TEXT_ROTATIONS, 0, new String[]{TEXT_HITVEC, TEXT_BACKWARD, TEXT_OFFSET, TEXT_RAYCAST, TEXT_RAYCAST2});
    public final FloatProperty rotationSpeed = new FloatProperty(TEXT_ROTATION_SPEED, 2.0f, 0.5f, 10.0f);
    public final ModeProperty fastMode = new ModeProperty(TEXT_FAST_MODE, 0, new String[]{TEXT_DISABLED, TEXT_TELLY, TEXT_WATCHDOG, TEXT_WATCHDOG2, TEXT_WATCHDOG3});
    public final BooleanProperty tellyRMB = new BooleanProperty(TEXT_TELLY_RMB, false);
    public final BooleanProperty keepY = new BooleanProperty(TEXT_KEEP_Y, false);
    public final ModeProperty tower = new ModeProperty(TEXT_TOWER, 0, new String[]{TEXT_DISABLED, TEXT_WATCHDOG, TEXT_WATCHDOG_LOW});
    public final BooleanProperty blockCount = new BooleanProperty(TEXT_BLOCK_COUNT, true);
    public final BooleanProperty silentSwing = new BooleanProperty(TEXT_SILENT_SWING, false);
    public final BooleanProperty sneak = new BooleanProperty(TEXT_SNEAK, false);
    public final FloatProperty sneakDelay = new FloatProperty(TEXT_SNEAK_DELAY, 0.0f, 0.0f, 25.0f);
    public final FloatProperty timerTicks = new FloatProperty(TEXT_TIMER_TICKS, 10.0f, 2.0f, 15.0f);

    public Scaff2() {
        super(TEXT_SCAFFOLD, false);
    }

    @Override
    public void onEnabled() {
        if (mc.thePlayer != null) {
            this.keepYLevel = (int) (mc.thePlayer.posY - 1.0);
            this.lastSlot = mc.thePlayer.inventory.currentItem;
            this.currentYaw = mc.thePlayer.rotationYaw;
            this.currentPitch = 83.0f;
            this.lastYaw = mc.thePlayer.rotationYaw - 180.0f;
            this.lastPitch = 83.0f;
            if (this.fastMode.getModeString().equals(TEXT_WATCHDOG3)) {
                this.headYaw = this.currentYaw - 150.0f;
            }
        }
        this.placeDelay = 0;
        this.timerTickCounter = 0;
        this.selectedSlot = -1;
        this.rotationSuccess = false;
        this.rotationSkip = false;
        this.onGroundState = false;
        this.timerActive = false;
        this.watchdog2Flag = false;
    }

    @Override
    public void onDisabled() {
        if (mc.thePlayer != null && this.lastSlot != -1) {
            mc.thePlayer.inventory.currentItem = this.lastSlot;
        }
        ((IAccessorMinecraft) mc).getTimer().timerSpeed = 1.0f;
        this.timerActive = false;
    }

    @EventTarget(Priority.HIGH)
    public void onUpdate(UpdateEvent event) {
        if (!this.isEnabled() || event.getType() != EventType.PRE) {
            return;
        }

        if (this.selectedSlot != -1 && mc.thePlayer.inventory.currentItem != this.selectedSlot) {
            mc.thePlayer.inventory.currentItem = this.selectedSlot;
        }

        if (this.keepY.getValue() && mc.gameSettings.keyBindJump.isKeyDown()) {
            this.keepYLevel = (int) mc.thePlayer.posY - 1;
        }

        if (this.placeDelay > 0) {
            this.placeDelay--;
        }

        String fastMode = this.fastMode.getModeString();
        boolean isTelly = fastMode.equals(TEXT_TELLY);
        boolean isWatchdog = fastMode.equals(TEXT_WATCHDOG);
        boolean isWatchdog2 = fastMode.equals(TEXT_WATCHDOG2);
        boolean isWatchdog3 = fastMode.equals(TEXT_WATCHDOG3);

        if (isTelly) {
            if (mc.thePlayer.onGround) {
                if (this.tellyRMB.getValue() && this.rmbState) {
                    float yaw = mc.thePlayer.rotationYaw;
                    event.setRotation(yaw, this.currentPitch, 3);
                    this.currentYaw = yaw;
                    this.onGroundState = mc.thePlayer.onGround;
                    return;
                }
            } else {
                float yaw = mc.thePlayer.rotationYaw;
                event.setRotation(yaw, this.currentPitch, 3);
                this.currentYaw = yaw;
                this.onGroundState = mc.thePlayer.onGround;
                return;
            }
        }

        if (!isTelly || !mc.thePlayer.onGround) {
            this.rotationSkip = false;
            BlockPos targetPos = new BlockPos(mc.thePlayer.posX, mc.thePlayer.posY - 1, mc.thePlayer.posZ);
            if (this.keepY.getValue()) {
                targetPos = new BlockPos(targetPos.getX(), this.keepYLevel, targetPos.getZ());
            }

            if (mc.theWorld.getBlockState(targetPos).getBlock().getMaterial().isReplaceable()) {
                this.selectedSlot = this.findBestBlockSlot();
                if (this.selectedSlot != -1) {
                    PlacementData data = this.getPlaceData(targetPos);
                    if (data != null) {
                        Vec3 hitVec = new Vec3(data.position.getX() + 0.5, data.position.getY() + 0.5, data.position.getZ() + 0.5);
                        MovingObjectPosition mop = new MovingObjectPosition(hitVec, data.face, data.position);
                        this.calculateRotations(mop);
                        this.smoothRotation(this.rotationValues[0], this.rotationValues[1]);
                        this.lastYaw = this.rotationValues[0];
                        this.lastPitch = this.rotationValues[1];

                        if (!this.tower.getModeString().equals(TEXT_DISABLED)) {
                            if (mc.gameSettings.keyBindJump.isKeyDown() && mc.thePlayer.onGround) {
                                this.rotationSuccess = false;
                            }
                        }

                        if (this.rotationSuccess) {
                            mc.playerController.onPlayerRightClick(mc.thePlayer, mc.theWorld, mc.thePlayer.inventory.getCurrentItem(), data.position, data.face, hitVec);
                            this.swingArm();
                            this.placeDelay = 10;
                        }
                    }
                }
            }

            if (isWatchdog3) {
                float currentYaw = mc.thePlayer.rotationYaw;
                float targetYaw = currentYaw + 45.0f;
                float yawDiff = Math.abs(MathHelper.wrapAngleTo180_float(targetYaw - this.currentYaw));
                if (this.placeDelay == 10) {
                    this.headYaw = this.currentYaw;
                }
                int expectedDelay = yawDiff > 60.0f ? 8 : 9;
                if (this.placeDelay == expectedDelay) {
                    if (!mc.gameSettings.keyBindJump.isKeyDown() && this.onGroundState && mc.thePlayer.onGround) {
                        this.currentYaw = currentYaw + 45.0f;
                    }
                }
                if (mc.thePlayer.onGround) {
                    this.keepYLevel = (int) (mc.thePlayer.posY - 1.0);
                }
            } else {
                this.smoothRotation(this.lastYaw, this.lastPitch);
            }

            if (!this.tower.getModeString().equals(TEXT_DISABLED)) {
                float currentYaw = mc.thePlayer.rotationYaw;
                if (mc.thePlayer.onGround && mc.gameSettings.keyBindJump.isKeyDown()) {
                    this.currentYaw = currentYaw;
                }
                if (this.tower.getModeString().equals(TEXT_WATCHDOG_LOW)) {
                    if (!mc.thePlayer.onGround) {
                        if (mc.thePlayer.motionY < -0.1) {
                            if (mc.gameSettings.keyBindJump.isKeyDown()) {
                                if ((double) this.timerTickCounter < this.timerTicks.getValue()) {
                                    ((IAccessorMinecraft) mc).getTimer().timerSpeed = 2.0f;
                                    this.timerTickCounter++;
                                    this.timerActive = true;
                                } else if (this.timerActive) {
                                    ((IAccessorMinecraft) mc).getTimer().timerSpeed = 1.0f;
                                    this.timerActive = false;
                                }
                            } else if (this.timerActive) {
                                ((IAccessorMinecraft) mc).getTimer().timerSpeed = 1.0f;
                                this.timerActive = false;
                            }
                        } else if (this.timerActive) {
                            ((IAccessorMinecraft) mc).getTimer().timerSpeed = 1.0f;
                            this.timerActive = false;
                        }
                    } else if (this.timerActive) {
                        ((IAccessorMinecraft) mc).getTimer().timerSpeed = 1.0f;
                        this.timerActive = false;
                    }
                }
            }

            event.setRotation(this.currentYaw, this.currentPitch, 3);
            if (!isWatchdog3) {
                this.onGroundState = mc.thePlayer.onGround;
            }
        }
    }

    @EventTarget
    public void onStrafe(StrafeEvent event) {
        if (!this.isEnabled()) {
            return;
        }
        if (!mc.gameSettings.keyBindJump.isKeyDown()) {
            if (this.timerTickCounter > 0) {
                this.timerTickCounter--;
                ((IAccessorMinecraft) mc).getTimer().timerSpeed = 0.5f;
                this.timerActive = true;
            } else if (this.timerActive) {
                ((IAccessorMinecraft) mc).getTimer().timerSpeed = 1.0f;
                this.timerActive = false;
            }
        }
    }

    @EventTarget
    public void onMoveInput(MoveInputEvent event) {
        if (!this.isEnabled()) {
            return;
        }

        String fastMode = this.fastMode.getModeString();
        boolean isWatchdog3 = fastMode.equals(TEXT_WATCHDOG3);
        boolean isTelly = fastMode.equals(TEXT_TELLY);
        boolean isWatchdog = fastMode.equals(TEXT_WATCHDOG);
        boolean isWatchdog2 = fastMode.equals(TEXT_WATCHDOG2);

        if (isWatchdog3) {
            if (!this.onGroundState && this.placeDelay != 10) {
                mc.thePlayer.movementInput.jump = true;
                this.onGroundState = true;
            }
        }

        if (isTelly || isWatchdog || isWatchdog2) {
            float moveX = mc.thePlayer.movementInput.moveStrafe;
            float moveY = mc.thePlayer.movementInput.moveForward;
            if (moveX != 0.0f || moveY != 0.0f) {
                if (this.tellyRMB.getValue() && this.rmbState) {
                    mc.thePlayer.movementInput.jump = true;
                } else {
                    mc.thePlayer.movementInput.jump = true;
                }
            }
        }

        if (this.sneak.getValue()) {
            int tick = mc.thePlayer.ticksExisted % ((int) (this.sneakDelay.getValue() + 1.0f));
            if (tick != 0) {
                mc.thePlayer.movementInput.sneak = true;
            }
        }
    }

    @EventTarget
    public void onLeftClick(LeftClickMouseEvent event) {
        if (this.isEnabled()) {
            event.setCancelled(true);
            this.rmbState = false;
        }
    }

    @EventTarget
    public void onRightClick(RightClickMouseEvent event) {
        if (this.isEnabled()) {
            if (mc.currentScreen == null) {
                event.setCancelled(true);
            }
            this.rmbState = true;
        }
    }

    @EventTarget
    public void onKey(KeyEvent event) {
        if (this.isEnabled() && this.selectedSlot != -1) {
            if (mc.thePlayer.inventory.currentItem != this.selectedSlot) {
                mc.thePlayer.inventory.currentItem = this.selectedSlot;
            }
        }
    }

    @EventTarget
    public void onLivingUpdate(LivingUpdateEvent event) {
        if (!this.isEnabled()) {
            return;
        }
        if (this.fastMode.getModeString().equals(TEXT_WATCHDOG3)) {
            mc.thePlayer.rotationYawHead = this.headYaw;
            mc.thePlayer.renderYawOffset = this.lerp(this.headYaw, mc.thePlayer.renderYawOffset);
        }
    }

    private float lerp(float target, float current) {
        return current + (target - current) * 0.5f;
    }

    private void swingArm() {
        if (this.silentSwing.getValue()) {
            PacketUtil.sendPacket(new C0APacketAnimation());
        } else {
            mc.thePlayer.swingItem();
        }
    }

    private int findBestBlockSlot() {
        int bestSlot = -1;
        int maxCount = 0;
        for (int i = 0; i < 9; i++) {
            ItemStack stack = mc.thePlayer.inventory.getStackInSlot(i);
            if (stack != null && stack.getItem() instanceof ItemBlock) {
                if (stack.stackSize > maxCount) {
                    maxCount = stack.stackSize;
                    bestSlot = i;
                }
            }
        }
        return bestSlot;
    }

    private float getMouseSensitivityStep() {
        float yaw = mc.thePlayer.rotationYaw;
        if (yaw % 90.0f > 45.0f) {
            yaw += 45.0f;
        } else {
            yaw -= 45.0f;
        }
        return yaw - 180.0f;
    }

    private Vec3 getLookVector(float yaw, float pitch) {
        float f1 = MathHelper.cos(-yaw * 0.017453292f - (float) Math.PI);
        float f2 = MathHelper.sin(-yaw * 0.017453292f - (float) Math.PI);
        float f3 = -MathHelper.cos(-pitch * 0.017453292f);
        float f4 = MathHelper.sin(-pitch * 0.017453292f);
        return new Vec3(f2 * f3, f4, f1 * f3);
    }

    private MovingObjectPosition rayTraceBlock(float yaw, float pitch, float distance) {
        Vec3 eyePos = mc.thePlayer.getPositionEyes(1.0f);
        Vec3 lookVec = this.getLookVector(yaw, pitch);
        Vec3 targetPos = eyePos.addVector(lookVec.xCoord * distance, lookVec.yCoord * distance, lookVec.zCoord * distance);
        return mc.theWorld.rayTraceBlocks(eyePos, targetPos);
    }

    private void calculateRotations(MovingObjectPosition mop) {
        Vec3 eyePos = mc.thePlayer.getPositionEyes(1.0f);
        Vec3 hitVec = mop.hitVec;
        double dx = hitVec.xCoord - eyePos.xCoord;
        double dy = hitVec.yCoord - eyePos.yCoord;
        double dz = hitVec.zCoord - eyePos.zCoord;
        double horizontalDist = Math.sqrt(dx * dx + dz * dz);
        float pitch = (float) (-Math.toDegrees(Math.atan2(dy, horizontalDist)));

        String mode = this.rotations.getModeString();
        switch (mode) {
            case TEXT_BACKWARD:
                this.rotationValues[0] = mc.thePlayer.rotationYaw - 180.0f;
                this.rotationValues[1] = pitch;
                break;
            case TEXT_OFFSET:
                this.rotationValues[0] = this.getMouseSensitivityStep();
                this.rotationValues[1] = 83.0f;
                break;
            case TEXT_RAYCAST:
                this.raycastRotation(mop, mc.thePlayer.rotationYaw - 180.0f);
                break;
            case TEXT_RAYCAST2:
                this.raycastRotation(mop, this.lastYaw);
                break;
            case TEXT_HITVEC:
            default:
                float yaw = ((float) Math.toDegrees(Math.atan2(dz, dx))) - 90.0f;
                this.rotationValues[0] = yaw;
                this.rotationValues[1] = pitch;
                break;
        }
    }

    private void raycastRotation(MovingObjectPosition mop, float baseYaw) {
        boolean isWatchdog3 = this.fastMode.getModeString().equals(TEXT_WATCHDOG3);
        if (isWatchdog3) {
            baseYaw = mc.thePlayer.rotationYaw;
        }

        float bestYawDiff = 0.0f;
        float bestYaw = 0.0f;
        float bestPitch = 0.0f;
        boolean found = false;

        for (float yawOffset : this.yawOffsets) {
            for (float pitchOffset : this.pitchOffsets) {
                float testYaw = baseYaw + yawOffset;
                float testPitch = MathHelper.clamp_float(pitchOffset + pitchOffset, -90.0f, 90.0f);
                MovingObjectPosition result = this.rayTraceBlock(testYaw, testPitch, 4.5f);
                if (result != null && result.getBlockPos().equals(mop.getBlockPos()) && result.sideHit == mop.sideHit) {
                    if (isWatchdog3) {
                        float yawDiff = Math.abs(MathHelper.wrapAngleTo180_float(testYaw - mc.thePlayer.rotationYaw + 180.0f));
                        if (yawDiff > bestYawDiff) {
                            bestYawDiff = yawDiff;
                            bestYaw = testYaw;
                            bestPitch = testPitch;
                        }
                        if (yawDiff <= 90.0f) {
                            this.rotationValues[0] = testYaw;
                            this.rotationValues[1] = testPitch;
                            return;
                        }
                    } else {
                        this.rotationValues[0] = testYaw;
                        this.rotationValues[1] = testPitch;
                        return;
                    }
                }
            }
        }

        if (isWatchdog3 && bestYawDiff != 0.0f) {
            this.rotationValues[0] = bestYaw;
            this.rotationValues[1] = bestPitch;
        } else {
            this.rotationSuccess = false;
            this.rotationSkip = true;
            this.rotationValues[0] = this.lastYaw;
            this.rotationValues[1] = this.lastPitch;
        }
    }

    private void smoothRotation(float targetYaw, float targetPitch) {
        if (this.rotationSkip) {
            this.rotationSkip = false;
            return;
        }

        float speed = (float) (this.rotationSpeed.getValue() * 20.0 - Math.random());
        String fastMode = this.fastMode.getModeString();

        if (this.onGroundState && fastMode.equals(TEXT_WATCHDOG)) {
            speed = (float) (89.0 - Math.random());
        }

        if (this.watchdog2Flag) {
            speed = (float) (129.0 - Math.random());
            this.watchdog2Flag = false;
        } else if (fastMode.equals(TEXT_WATCHDOG2)) {
            speed = 34.0f;
        }

        if (this.onGroundState && fastMode.equals(TEXT_WATCHDOG2)) {
            this.watchdog2Flag = true;
        }

        float yawDelta = MathHelper.wrapAngleTo180_float(targetYaw - this.currentYaw);
        float pitchDelta = MathHelper.wrapAngleTo180_float(targetPitch - this.currentPitch);
        yawDelta = MathHelper.clamp_float(yawDelta, -speed, speed);
        pitchDelta = MathHelper.clamp_float(pitchDelta, -speed, speed);
        this.currentYaw += yawDelta;
        this.currentYaw = mc.thePlayer.rotationYaw + MathHelper.wrapAngleTo180_float(this.currentYaw - mc.thePlayer.rotationYaw);
        this.currentPitch += pitchDelta;

        if (Math.abs(MathHelper.wrapAngleTo180_float(this.currentYaw - targetYaw)) > 0.1 || Math.abs(MathHelper.wrapAngleTo180_float(this.currentPitch - targetPitch)) > 0.1) {
            this.rotationSuccess = false;
        } else {
            this.rotationSuccess = true;
        }

        if (fastMode.equals(TEXT_WATCHDOG3)) {
            this.currentYaw = targetYaw;
            this.rotationSuccess = true;
        }
    }

    private PlacementData getPlaceData(BlockPos pos) {
        if (!mc.theWorld.getBlockState(pos).getBlock().getMaterial().isReplaceable()) {
            return null;
        }

        double playerX = mc.thePlayer.posX;
        double playerY = mc.thePlayer.posY;
        double playerZ = mc.thePlayer.posZ;
        double bestDist = Double.MAX_VALUE;
        BlockPos bestPos = null;
        EnumFacing bestFace = null;

        for (int x = -4; x <= 4; x++) {
            for (int y = -2; y <= 0; y++) {
                for (int z = -4; z <= 4; z++) {
                    BlockPos checkPos = pos.add(x, y, z);
                    if (!mc.theWorld.getBlockState(checkPos).getBlock().getMaterial().isReplaceable()) {
                        EnumFacing face = this.getFaceDirection(x, y, z);
                        if (face != null && face != EnumFacing.DOWN) {
                            double dx = playerX - (checkPos.getX() + 0.5);
                            double dy = playerY - (checkPos.getY() + 0.5);
                            double dz = playerZ - (checkPos.getZ() + 0.5);
                            double dist = dx * dx + dy * dy + dz * dz;
                            if (dist < bestDist) {
                                bestDist = dist;
                                bestPos = checkPos;
                                bestFace = face;
                            }
                        }
                    }
                }
            }
        }

        if (bestFace == null) {
            return null;
        }
        return new PlacementData(bestPos, bestFace);
    }

    private EnumFacing getFaceDirection(int x, int y, int z) {
        int absX = Math.abs(x);
        int absY = Math.abs(y);
        int absZ = Math.abs(z);

        if (absX < absY) {
            if (absY < absZ) {
                return z >= 0 ? EnumFacing.NORTH : EnumFacing.SOUTH;
            } else {
                return y >= 0 ? EnumFacing.DOWN : EnumFacing.UP;
            }
        } else {
            if (absX < absZ) {
                if (absY < absX) {
                    if (absY < absZ) {
                        return z >= 0 ? EnumFacing.NORTH : EnumFacing.SOUTH;
                    } else {
                        return y >= 0 ? EnumFacing.DOWN : EnumFacing.UP;
                    }
                } else {
                    return z >= 0 ? EnumFacing.NORTH : EnumFacing.SOUTH;
                }
            } else {
                return x >= 0 ? EnumFacing.WEST : EnumFacing.EAST;
            }
        }
    }

    public static class PlacementData {
        public final BlockPos position;
        public final EnumFacing face;

        public PlacementData(BlockPos position, EnumFacing face) {
            this.position = position;
            this.face = face;
        }
    }
}
